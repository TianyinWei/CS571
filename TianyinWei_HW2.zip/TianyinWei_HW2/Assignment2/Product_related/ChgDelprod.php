<?php

session_start();
$t = time();
if ($_SESSION['usertype']=='Employee'){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p>';
        require "postlogin.html";
        session_destroy();
    }else{
$s = $_POST['submit'];
//$uname = $_POST['username'];

$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);

$sql1 = "SELECT * FROM Product";
$res = mysql_query($sql1);

if($s=='ModifyProd') {
    require 'preModifyProd.html';
    while ($row = mysql_fetch_assoc($res)) {
        echo '<input type="radio" name="chgprod" value="'.$row['productID'].'"/>productID:'.$row['productID'].'     product categoryID:' . $row['prodcategoryID'] . '   product name:' . $row['prodname'] . '     product price:' . $row['prodprice'] . '<br>';
    }
    echo '<input type="submit" name="changeprod" class="add add-submit" value="Change selected product info"></form></div></body></html>';
    //require 'postModifyProd.html';
}



if($s=='DeleteProd'){
    require 'preDelprod.html';
    while($row = mysql_fetch_assoc($res)) {
        echo '<input type="checkbox" name="delprod[]" value="'.$row['productID'].'"/>productID:'.$row['productID'].'    product categoryID:'.$row['prodcategoryID'].'   product name:'.$row['prodname'].'     product price:'.$row['prodprice'].'<br>';
    }
    echo '<input type="submit" name="deleteprod" class="add add-submit" value="Delete selected products"></form></div></body></html>';
    //require 'postDelprod.html';
}

mysql_close($con);
    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p>';
    require "postlogin.html";
}
?>