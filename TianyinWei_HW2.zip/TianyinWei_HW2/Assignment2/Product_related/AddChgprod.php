<?php

session_start();
$t = time();
if ($_SESSION['usertype']=='Employee'){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p>';
        require "postlogin.html";
        session_destroy();
    }else{
$s = $_POST['submit'];
$prodID = "";

$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);



if (isset($_POST['chgprod'])){
    $prodID = $_POST['chgprod'];
    require 'preSQLChgprod.html';
    $sql1 = "SELECT * FROM Product WHERE productID=$prodID";
    $res = mysql_query($sql1);
    $row = mysql_fetch_assoc($res);
    //print_r($userindex);
    echo 'product name:<input type="text" name="productname" value="'.$row['prodname'].'"><br><br>';
    echo 'product categoryID:<input type="number" name="prodctgID" value="'.$row['prodcategoryID'].'" readonly><br><br>';
    echo 'product description:<input type="text" name="productdesc" value="'.$row['proddescription'].'"><br><br>';
    echo 'product image:<input type="text" name="productimg" value="'.$row['prodimg'].'"><br><br>';
    echo 'product price:<input type="number" name="productprice" value="'.$row['prodprice'].'"><br><br>';

    echo '<input type="hidden" name="prodID" value="'.$row['productID'].'">';
    echo '<br>';
    echo '<input type="submit" name="CHANGE" class="add add-submit" value="Modify product info">  </form></body></div></html>';
}

if (!$prodID) {
    require "Addprod.html";

}


mysql_close($con);
}
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p>';
    require "postlogin.html";
}

?>