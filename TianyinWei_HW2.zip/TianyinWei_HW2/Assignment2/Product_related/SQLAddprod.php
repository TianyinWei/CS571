<?php
session_start();
$t = time();
if ($_SESSION['usertype']=='Employee'){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p>';
        require "postlogin.html";
        session_destroy();
    }else{
$name = "'".$_POST['productname']."'";
$ctgID = "'".$_POST['productctgID']."'";
$desc = "'".$_POST['productdesc']."'";
$img = "'".$_POST['productimg']."'";
$price = "'".$_POST['productprice']."'";

$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);

//print_r($age);

$sql = "INSERT INTO Product(prodcategoryID,prodname,proddescription,prodimg,prodprice)VALUES ($ctgID,$name,$desc,$img,$price)";
if(mysql_query($sql)){
    require 'testprod.html';
    echo '<input type="submit" name="Emphome" class="add add-submit" value="Back to home page">';
    echo '<p>New product created successfully!</p></form></body></html>';}
    else{
        require 'testprod.html';
        echo '<input type="submit" name="Emphome" class="add add-submit" value="Back to home page">';
        echo '<p>Error in creating the product.</p></form></body></html>';}

mysql_close($con);
    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p>';
    require "postlogin.html";
}
?>