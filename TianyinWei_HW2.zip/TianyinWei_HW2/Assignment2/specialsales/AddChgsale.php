<?php
session_start();
$t = time();
if ($_SESSION['usertype']=='Employee'){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p>';
        require "postlogin.html";
        session_destroy();
    }else{
$s = $_POST['submit'];
$prodID = "";

$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);



if (isset($_POST['chgsale'])){
    $prodID = $_POST['chgsale'];
    require 'preSQLChgsale.html';
    $sql1 = "SELECT * FROM Product WHERE productID=$prodID";
    $res1 = mysql_query($sql1);
    $row1 = mysql_fetch_assoc($res1);

    $sql3 = "SELECT * FROM SpecialSales WHERE productID=$prodID";
    $res3 = mysql_query($sql3);
    $row3 = mysql_fetch_assoc($res3);
    //print_r($userindex);
    echo 'ProductID:<input type="text" id="productID" name="productID" value="'.$row1['productID'].'" readonly><br><br>';
    echo 'Product name:<input type="text" id="productname" name="productname" value="'.$row1['prodname'].'" readonly><br><br>';
    echo 'CategoryID:<input type="number" id="prodctgID" name="prodctgID" value="'.$row1['prodcategoryID'].'" readonly><br><br>';
    echo 'Discount(amount off):<input type="number" step="0.01" id="productdesc" name="discount" min="0" max="1" value='.$row3['discount'].' required/><br><br>';
    echo 'Start date:<input type="date" id="productimg" name="startdate" value='.$row3['startdate'].' required/><br><br>';
    echo 'End date:<input type="date" id="productprice" name="enddate" value='.$row3['enddate'].' required/><br><br>';
    echo 'New price:<input type="number" step="0.01" id="newprice" name="newprice" value='.$row1['prodprice'].' required/><br><br><br>';
    echo '<input type="submit" id="createproduct" name="submit" class="add add-submit" value="Confirm Change"></form></div></body></html>';

}

if (!$prodID) {
    require "Addsale.html";
    $sql2 =   "SELECT * FROM Product ";
    $res = mysql_query($sql2);
    while ($row = mysql_fetch_assoc($res)) {
        echo '<input type="radio" name="addsale" value="'.$row['productID'].'"/>ProductID:'.$row['productID'].' Product name:' . $row['prodname'] . '     Product price:' . $row['prodprice'] . '<br>';
    }
    echo '<input type="submit" name="confirmadd" class="add add-submit" value="Confirm this product"></form></div></body></html>';
    }




mysql_close($con);
    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p>';
    require "postlogin.html";
}

?>