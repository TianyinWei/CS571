<?php
session_start();
$t = time();
if ($_SESSION['usertype']=='Employee'){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p>';
        require "postlogin.html";
        session_destroy();
    }else{
$prodID = "'".$_POST['productID']."'";
//$name = "'".$_POST['productname']."'";
$ctgID = "'".$_POST['prodctgID']."'";
$discount = "'".$_POST['discount']."'";
$start = "'".$_POST['startdate']."'";
$end = "'".$_POST['enddate']."'";
$price = "'".$_POST['newprice']."'";


$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);

$sql1 = "INSERT INTO SpecialSales(productID,categoryID,discount,startdate,enddate,price)VALUES ($prodID,$ctgID,$discount,$start,$end,$price)";

//$res2 = mysql_query($sql2);

if(mysql_query($sql1)){
	//$sql2 = "SELECT * FROM Product WHERE productID=$prodID";
	//$res2 = mysql_query($sql2);
    require 'testprod.html';
    //print_r($row['prodprice']);

    echo '<input type="submit" name="Emphome" class="add add-submit" value="Back to home page">';
    echo '<p>New sale created successfully!</p></form></body></html>';}
    else{
        require 'testprod.html';
        echo '<input type="submit" name="Emphome" class="add add-submit" value="Back to home page">';
        echo '<p>Error in creating the sale.</p></form></body></html>';}

mysql_close($con);
    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p>';
    require "postlogin.html";
}

?>