<?php
session_start();
$t = time();
if ($_SESSION['usertype']=='Manager'){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p>';
        require "postlogin.html";
        session_destroy();
    }else{

$con = mysql_connect('cs-server.usc.edu:7816','root','920328');
if(!$con){
    die ("connection fail!");
}
mysql_select_db('mydatabase',$con);

$sql = "SELECT * FROM ProdCategory";
$res = mysql_query($sql);
require 'viewSalectg.html';
echo '<select name="ctgname">';
while ($row = mysql_fetch_assoc($res)) {

    echo '<option value="'.$row['prodcategoryID'].'"/>' . $row['prodcategoryname'] . '</option>';
}
echo '</select>';
echo '<input type="submit" name="viewProdname" class="add add-submit" value="Confirm"></form></div></body></html>';


mysql_close($con);
    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p>';
    require "postlogin.html";
}

?>