<?php
session_start();
$t = time();
if ($_SESSION['usertype']=='Manager'){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p>';
        require "postlogin.html";
        session_destroy();
    }else{

$lowpay = $_POST['lowpay'];
$highpay = $_POST['highpay'];
//print_r($lowpay);
$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
die ("connection fail!");
}
mysql_select_db('mydatabase', $con);

$sql1 = "SELECT * FROM user WHERE payment BETWEEN $lowpay AND $highpay";
$result1 = mysql_query($sql1);

require "viewEmppay.html";

echo "<table>
    <tr>
        <th>Username</th>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Usertype</th>
        <th>Age</th>

    </tr>";
    while ($row = mysql_fetch_assoc($result1)) {
    echo "<tr>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . $row['firstname'] . "</td>";
        echo "<td>" . $row['lastname'] . "</td>";
        echo "<td>" . $row['usertype'] . "</td>";
        echo "<td>" . $row['age'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
echo '</form></div></body></html>';


mysql_close($con);
    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p>';
    require "postlogin.html";
}


?>