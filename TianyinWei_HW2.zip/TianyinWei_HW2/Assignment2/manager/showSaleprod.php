<?php
session_start();
$t = time();
if ($_SESSION['usertype']=='Manager'){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p>';
        require "postlogin.html";
        session_destroy();
    }else{

$prodID = $_POST['prodname'];
$con = mysql_connect('cs-server.usc.edu:7816','root','920328');
if(!$con){
    die ("connection fail!");
}
mysql_select_db('mydatabase',$con);

$sql = "SELECT * FROM SpecialSales WHERE productID=$prodID";
$res = mysql_query($sql);
require 'saleProd.html';

if($res) {
    echo "<table>
<tr>
<th>ProductID</th>
<th>Discount</th>
<th>Startdate</th>
<th>Enddate</th>
<th>Price</th>

</tr>";
    while ($row = mysql_fetch_assoc($res)) {
        echo "<tr>";
        echo "<td>" . $row['productID'] . "</td>";
        echo "<td>" . $row['discount'] . "</td>";
        echo "<td>" . $row['startdate'] . "</td>";
        echo "<td>" . $row['enddate'] . "</td>";
        echo "<td>" . $row['price'] . "</td>";

        echo "</tr>";
    }
    echo "</table>";
    echo '</form></div></body></html>';
}
else{
    //require 'previewProdname.html';
    echo "<p>no matched products</p>";
    echo '</form></div></body></html>';

}

mysql_close($con);
    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p>';
    require "postlogin.html";
}

?>