<?php
	session_start();
	$_SESSION['timeout'] = time();
	//print_r($_SESSION['timeout']);
	$un = $_POST['username'];
	$pw = $_POST['pw'];
	$errmsg = "";
	$usertype = "";

	if (strlen($un) == 0){
		$errmsg = 'Please enter username';
	}
	if (strlen($pw) == 0){
		$errmsg = 'Please enter password';
	}
	if (strlen($un) == 0 && strlen($pw) == 0){
		$errmsg = "";
	}
	if (strlen($un) >0 && strlen($pw) >0){
		$sql = "select usertype from user where username='".$un."' and password='".$pw."'";
		$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
		if (!$con) {
			die("connection fail");	}
		mysql_select_db('mydatabase',$con);
		$res = mysql_query($sql);
		if (!($row = mysql_fetch_assoc($res))) {
			$errmsg = 'Username or password is invalid';
		} else {
			$usertype = $row['usertype'];
		}
		mysql_close($con);
	}
	if(strlen($errmsg)>0){
		require 'prelogin.html';
		echo '<p style="color:red">'.$errmsg.'</p>';
		require 'postlogin.html';
	}elseif (!$res) {
		require 'prelogin.html';
		require 'postlogin.html';
	}else{
		$_SESSION['usertype']=$usertype;
		$_SESSION['username']=$username;

		if ($usertype=='Administrator') {header("location: Admin.html") ;}
		if ($usertype=='Employee') {header("location: Employee.html");}
		if ($usertype=='Manager') {header("location: Manager.html");}

	}
	
?>