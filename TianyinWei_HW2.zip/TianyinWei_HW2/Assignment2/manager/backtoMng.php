<?php
session_start();
$t = time();
if ($_SESSION['usertype']=='Manager'){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p>';
        require "postlogin.html";
        session_destroy();
    }else{

require "Manager.html";
    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p>';
    require "postlogin.html";
}
?>