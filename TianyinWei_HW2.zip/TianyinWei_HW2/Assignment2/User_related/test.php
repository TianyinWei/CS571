<?php
session_start();
$t = time();
if ($_SESSION['usertype']=='Administrator'){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p>';
        require "postlogin.html";
        session_destroy();
    }else{
$prodID = "'".$_POST['productID']."'";
$name = "'".$_POST['productname']."'";
$ctgID = "'".$_POST['prodctgID']."'";
$discount = "'".$_POST['discount']."'";
$start = "'".$_POST['startdate']."'";
$end = "'".$_POST['enddate']."'";

$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);


print_r($prodID);
print_r($name);
print_r($ctgID);
print_r($discount);
print_r($start);
print_r($end);

$sql = "INSERT INTO Special Sales(productID, prodname,categoryID,discount,startdate,enddate)VALUES ($prodID,$name,$ctgID,$discount,$start,$end)";
if(mysql_query($sql)){
    require 'testprod.html';
    echo '<input type="submit" name="Emphome" class="add add-submit" value="Back to home page">';
    echo '<p>New sale created successfully!</p></form></body></html>';}
else{
    require 'testprod.html';
    echo '<input type="submit" name="Emphome" class="add add-submit" value="Back to home page">';
    echo '<p>Error in creating the sale.</p></form></body></html>';}

mysql_close($con);
    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p>';
    require "postlogin.html";
}
?>