<?php
    session_start();
    $t = time();
    if ($_SESSION['usertype']=='Administrator'){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p>';
        require "postlogin.html";
        session_destroy();
    }else{

$s = $_POST['submit'];
$userindex = "";

$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);



if (isset($_POST['chguser'])){
    $userindex = $_POST['chguser'];
    require 'preSQLChguser.html';
    $sql1 = "SELECT * FROM user WHERE userindex=$userindex";
    $res = mysql_query($sql1);
    $row = mysql_fetch_assoc($res);
    //print_r($userindex);
    echo 'Username:<input type="text" name="username" value="'.$row['username'].'"><br><br>';
    echo 'Password:<input type="text" name="pw" value="'.$row['password'].'"><br><br>';
    echo 'Firstname:<input type="text" name="fname" value="'.$row['firstname'].'"><br><br>';
    echo 'Lastname:<input type="text" name="lname" value="'.$row['lastname'].'"><br><br>';
    echo 'Usertype:<select name="usertype" id="usertype" required/>';
    echo '<option value ="'.$row['usertype'].'">'.$row['usertype'].'</option><option value ="Manager">Manager</option><option value ="Employee">Employee</option><option value ="Administrator">Administrator</option>';
    echo '</select><br><br>';
    echo 'Age:<input type="number" name="age" value="'.$row['age'].'"><br><br>';
    echo 'Payment:<input type="number" name="payment" value="'.$row['payment'].'"><br><br>';
    echo '<input type="hidden" name="userindex" value="'.$row['userindex'].'"><br><br>';
    echo '<br><br>';
    echo '<input type="submit" name="CHANGE" class="add add-submit" value="Modify user info">  </form></div></body></html>';
}

if (!$userindex) {
    require "Adduser.html";
    echo "</div></body></html>";}

mysql_close($con);
}
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p>';
    require "postlogin.html";
    }


?>