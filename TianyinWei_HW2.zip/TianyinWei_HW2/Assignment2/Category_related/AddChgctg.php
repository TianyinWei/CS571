<?php
$t = time();
session_start();
if ($_SESSION['usertype']=='Employee'){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p>';
        require "postlogin.html";
        session_destroy();
    }else{
$s = $_POST['submit'];
$ctgID = "";

$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);



if (isset($_POST['chgctg'])){
    $ctgID = $_POST['chgctg'];
    require 'preSQLChgctg.html';
    $sql1 = "SELECT * FROM ProdCategory WHERE prodcategoryID=$ctgID";
    $res = mysql_query($sql1);
    $row = mysql_fetch_assoc($res);
    //print_r($userindex);
    echo 'product category name:<input type="text" name="ctgname" value="'.$row['prodcategoryname'].'"><br><br>';
    echo 'product category description:<input type="text" name="ctgdesc" value="'.$row['prodcategorydesc'].'"><br><br>';

    echo '<input type="hidden" name="prodcategoryID" value="'.$row['prodcategoryID'].'">';
    echo '<br>';
    echo '<input type="submit" name="CHANGE" class="add add-submit" value="Modify category info">  </form></div></body></html>';
}

if (!$ctgID) {
    require "Addctg.html";

}


mysql_close($con);
    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p>';
    require "postlogin.html";
}

?>