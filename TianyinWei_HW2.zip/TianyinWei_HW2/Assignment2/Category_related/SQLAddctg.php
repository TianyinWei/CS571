<?php

$t = time();
session_start();
if ($_SESSION['usertype']=='Employee'){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p>';
        require "postlogin.html";
        session_destroy();
    }else{
$name = "'".$_POST['ctgname']."'";
$desc = "'".$_POST['ctgdesc']."'";

$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);

//print_r($age);

$sql = "INSERT INTO ProdCategory(prodcategoryname,prodcategorydesc)VALUES ($name,$desc)";
if(mysql_query($sql)){
    require 'testprod.html';
    echo '<input type="submit" name="Emphome" class="add add-submit" value="Back to home page">';
    echo '<p>New category created successfully!</p></form></body></html>';}
else{
    require 'testprod.html';
    echo '<input type="submit" name="Emphome" class="add add-submit" value="Back to home page">';
    echo '<p>Error in creating the category.</p></form></body></html>';
}

mysql_close($con);
    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p>';
    require "postlogin.html";
}

?>