<?php if(!defined('BASEPATH'))exit('No direct script access allowed');
/* calculate total price OK*/
/* insert into orderinfo OK*/
/* insert multiple items to orderitem OK*/
/* product table storage=storage-quantity OK*/
/* clear shopping cart of that customer OK*/
/* how to show date OK*/

class Placeorder extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        session_start();

    }

    public function index()
    {
        $t = time();
        if ($_SESSION['customer']) {

            if (($_SESSION['timeout'] + 180) < $t) {
                //header("location:mylogin.php");
                $flag = 2;
                $data = array("flag"=> $flag);
                $this -> load -> view("prelogin",$data);

                session_destroy();
            } else {

                $customer = "'" . $_SESSION['customer'] . "'";
                 $fname = "'" . $_POST['fname'] . "'";
                 $lname = "'" . $_POST['lname'] . "'";
                 $addr = "'" . $_POST['addr'] . "'";
                 $zipcode = "'" . $_POST['zipcode'] . "'";

                /*$fname = $this->input->post('fname');
                $lname = $this->input->post('lname');
                $addr = $this->input->post('addr');
                $zipcode = $this->input->post('zipcode');*/


                $this->form_validation->set_rules('fname', 'firstname', 'required|callback_fnameRegex');
                $this->form_validation->set_rules('lname', 'lastname', 'required|callback_lnameRegex');
                $this->form_validation->set_rules('addr', 'address', 'required|callback_addrRegex');
                $this->form_validation->set_rules('zipcode', 'zipcode', 'required');
                if ($this->form_validation->run() == FALSE) {
                    $this->load->view("registerinfo");
                } else {
                    $this->load->model("Placeorder_model");


//get customerID


                    $row0 = $this->Placeorder_model->getcustomer($customer);
                    $customerID = $row0['customerID'];

//caculate total price and quantity

                    $row4 = $this->Placeorder_model->totalprice($customer);
                    $totalprice = $row4['SUM(price*quantity)'];

                    $row44 = $this->Placeorder_model->totalqty($customer);
                    $totalqty = $row44['SUM(quantity)'];


                    $res5 = $this->Placeorder_model->addtoorderinfo($customer, $totalprice, $totalqty, $fname, $lname, $addr, $zipcode);


//substract storage in Product by order quantity
                    $res6 = $this->Placeorder_model->getcart($customer);
                    // while ($row6 =$this -> Placeorder_model -> getrow($res6)) {
                    foreach ($this->Placeorder_model->getrow($res6) as $row6) {
                        $prodID = $row6['productID'];
                        $quantity = $row6['quantity'];

                        $row7 = $this->Placeorder_model->getproduct($prodID);
                        $storage = $row7['storage'];

                        $newstorage = $storage - $quantity;
                        $res8 = $this->Placeorder_model->updatestorage($newstorage, $prodID);
                    }


//isert multiple items to orderitem

                    $row11 = $this->Placeorder_model->lastinsert();
                    $last = $row11['last_insert_id()']; //get last insert ID

                    $res22 = $this->Placeorder_model->getcart($customer);
                    //while ($row22 = $this -> Placeorder_model -> getrow($res22)) {
                    foreach ($this->Placeorder_model->getrow($res22) as $row22) {
                        $prodID = $row22['productID'];
                        $prodname = "'" . $row22['prodname'] . "'";
                        $catID = $row22['catID'];
                        $price = $row22['price'];
                        $quantity = $row22['quantity'];
                        $res10 = $this->Placeorder_model->addtoorderitem($last, $customerID, $customer, $prodname,
                            $prodID, $catID, $price, $quantity);

                    }

//delete corresponding shopping cart
                    $res9 = $this->Placeorder_model->delcart($customer);
                    $rowbug = $this->Placeorder_model->selorderinfo($customer);


                    $flag = 6;
                    $data = array("flag" => $flag);
                    $this->load->view("Cart.html", $data);

                }
            }

        } else {
            $flag = 1;
            $data = array("flag"=> $flag);
            $this -> load -> view("prelogin",$data);
        }
    }


    public function fnameRegex($firstname) {
        if (preg_match('/[^a-zA-Z\s]/',$firstname)) {
            $this->form_validation->set_message('fnameRegex', 'firstname can only have letters and space!');

            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function lnameRegex($lastname) {
        if (preg_match('/[^a-zA-Z\s]/',$lastname)) {
            $this->form_validation->set_message('lnameRegex', 'lastname can only have letters and space!');

            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function addrRegex($addr) {
        if (preg_match('/[^a-zA-Z0-9\s]/',$addr)) {
            $this->form_validation->set_message('addrRegex', 'address can only have letters,numbers and space!');

            return FALSE;
        } else {
            return TRUE;
        }
    }
}