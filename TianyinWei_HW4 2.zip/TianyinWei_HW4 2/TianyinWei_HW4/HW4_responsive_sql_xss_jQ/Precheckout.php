<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Precheckout extends CI_Controller
{

    public function __construct(){
        parent::__construct();
        session_start();

    }

    public function index()
    {
        $t = time();
        if ($_SESSION['customer']) {

            if (($_SESSION['timeout'] + 180) < $t) {
                $flag = 2;
                $data = array("flag"=> $flag);
                $this -> load -> view("prelogin",$data);
                session_destroy();
            } else {
                $customer = "'" . $_SESSION['customer'] . "'";

                $this -> load -> model("Precheck_model");

                $res1 = $this -> Precheck_model -> getcart($customer);
                $row2 = $this -> Precheck_model -> getcustomer($customer);


                $flag = 5;
                $data = array("flag" => $flag);
                $this->load->view("Cart.html", $data);

               // while ($row1 = $this -> Precheck_model -> getrow($res1)) {
                foreach($this -> Precheck_model -> getrow($res1) as $row1){
                    $prodID = $row1['productID'];
                    $row3 = $this -> Precheck_model -> getproduct($prodID);

                    $data['row1'] = $row1;
                    $data['row3'] = $row3;
                    $this->load->view("showorder", $data);

                }

                $data = array("row2" => $row2);
                $this->load->view("shipinfo", $data);


            }
        } else {
            $flag = 1;
            $data = array("flag"=> $flag);
            $this -> load -> view("prelogin",$data);
        }
    }
}