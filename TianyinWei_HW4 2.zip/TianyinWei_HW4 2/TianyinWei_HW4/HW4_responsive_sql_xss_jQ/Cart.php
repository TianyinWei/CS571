<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Cart extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        session_start();

    }

    public function index()
    {
        $t = time();
        if ($_SESSION['customer']) {

            if (($_SESSION['timeout'] + 180) < $t) {
                //header("location:mylogin.php");
                $flag = 2;
                $data = array("flag"=> $flag);
                $this -> load -> view("prelogin",$data);

                session_destroy();
            } else {

                $quantity = "'" . $_POST['quantity'] . "'";
                $prodname = $_SESSION['cartprodname'];
                $price = $_SESSION['cartprodprice'];
                $customer = "'" . $_SESSION['customer'] . "'";
                $prodID = "'" . $_POST['productID'] . "'";
                $catID = "'" . $_POST['catID'] . "'";

                $this -> load -> model("Cart_model");


                $res1 = $this -> Cart_model -> addtocart($customer,$prodname,$prodID,
                    $price,$quantity,$catID);

                $flag = 2;
                $data = array("res1"=>$res1,"flag"=>$flag);
                $this -> load -> view("Cart.html",$data);


            }
        } else {
            $flag = 1;
            $data = array("flag"=> $flag);
            $this -> load -> view("prelogin",$data);

        }
    }
}