<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Prodpage extends CI_Controller
{
        public function __construct()
        {
            parent::__construct();
            session_start();
        }

        public function index()
        {
            if ($_SESSION['customer']) {
                $t = time();
                if (($_SESSION['timeout'] + 180) < $t) {
                    $flag = 2;
                    $data = array("flag"=> $flag);
                    $this -> load -> view("prelogin",$data);
                    session_destroy();
                } else {

                    $customer = $_SESSION['customer'];
                    $data = array("customer"=>$customer);

                    $this -> load -> model("Prodpage_model");
                    date_default_timezone_set('America/Los_Angeles');
                    $today = date("Y-m-d"); // ("Y-m-d H:i:s") - DateTime


                    $res4 = $this -> Prodpage_model -> getcatnames();
                    $this -> load -> view("prodpage.html",$data);

                    //while ($row4 = $this -> Prodpage_model -> getrow($res4)) {

                    $this -> load -> view("spans");


                    $res2 = $this -> Prodpage_model -> getproduct();
                   // while ($row2 =$this -> Prodpage_model -> getrow($res2)) {
                    foreach($this -> Prodpage_model -> getrow($res2) as $row2){

                        $res3 = $this -> Prodpage_model -> getspecialsales($row2['productID']);
                        //$row3 = $this -> Prodpage_model -> getrow($res3);
                        $row3 = $this -> Prodpage_model -> getonerow($res3);
                        $enddate = "'" . $row3['enddate'] . "'";

                        $data = array("enddate"=>$enddate,"today"=>$today);
                        $data['row2'] = $row2;
                        $data['row3'] = $row3;
                        $this -> load -> view("viewdetail",$data);
                    }

                }
            } else {
                $flag = 1;
                $data = array("flag"=> $flag);
                $this -> load -> view("prelogin",$data);

            }

        }
}