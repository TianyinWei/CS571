<?php if(!defined('BASEPATH'))exit('No direct script access allowed');


class Mylogin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        session_start();
    }
    public function index()
    {
        $_SESSION['timeout'] = time();
        //$un = $_POST['username'];
        //$pw = $_POST['pw'];
        $un = $this -> input -> post('username');
        $pw = $this -> input -> post('pw');
        $errmsg = "";
        $usertype = "";
        //$s = $_POST['submit'];
        $s = $this -> input -> post('submit');
        if ($s == 'New member?Register NOW!') {
            $this->load->view("registerinfo");
        } else {

            if (strlen($un) == 0) {
                $errmsg = 'Please enter username';
            }
            if (strlen($pw) == 0) {
                $errmsg = 'Please enter password';
            }
            if (strlen($un) == 0 && strlen($pw) == 0) {
                $errmsg = "";
            }
            if (strlen($un) > 0 && strlen($pw) > 0) {

                $this->load->model("Mylogin_model");

                $res = $this->Mylogin_model->getunamepw($un, $pw);
                if (!($row = $this->Mylogin_model->getrow($res))) {
                    $errmsg = 'Username or password is invalid';
                } else {
                }
                // mysql_close($con);
            }
            $data = array("errmsg" => $errmsg);
            if (strlen($errmsg) > 0) {

                $this->load->view('prelogin');
                $this->load->view('showerrmsg', $data);
                $this->load->view('endprelogin');
            } elseif (!$res) {

                $this->load->view('prelogin');
                $this->load->view('endprelogin');
            } else {
                header("location:Prodpage");
                $_SESSION['customer'] = $un;
                //  $_SESSION['username'] = $username;

            }
        }
    }

}