<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Editprofile extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        session_start();
    }

    public function index()
    {

        $t = time();
        if ($_SESSION['customer']) {

            if (($_SESSION['timeout'] + 180) < $t) {
                $flag = 2;
                $data = array("flag"=> $flag);
                $this -> load -> view("prelogin",$data);
                session_destroy();
            } else {

                $customer = "'" . $_SESSION['customer'] . "'";

               $this -> load -> model("Editprofile_model");
                $row = $this -> Editprofile_model -> getcustomer($customer);
                $username = $row['username'];
                $pw = $row['password'];

                $flag = 9;
                $data = array("flag" => $flag,"row"=>$row,"username"=>$username,"pw"=>$pw);
                $this->load->view("Cart.html", $data);

            }
        } else {
            $flag = 1;
            $data = array("flag"=> $flag);
            $this -> load -> view("prelogin",$data);

        }
    }
}