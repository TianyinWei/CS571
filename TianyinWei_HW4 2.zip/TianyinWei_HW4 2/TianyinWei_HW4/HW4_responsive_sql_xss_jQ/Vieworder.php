<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Vieworder extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        session_start();
    }

    public function index()
    {
        $t = time();
        if ($_SESSION['customer']) {

            if (($_SESSION['timeout'] + 180) < $t) {
                $flag = 2;
                $data = array("flag"=> $flag);
                $this -> load -> view("prelogin",$data);
                session_destroy();
            } else {

                $customer = "'" . $_SESSION['customer'] . "'";

               $this -> load -> model("Vieworder_model");

                $res1 = $this -> Vieworder_model -> selorderinfo($customer);
                $row2 = $this -> Vieworder_model -> getcustomer($customer);

                $flag = 7;
                $data = array("flag" => $flag);
                $this->load->view("Cart.html", $data);

                //while ($row1 = $this -> Vieworder_model -> getrow($res1)) {
                foreach($this -> Vieworder_model -> getrow($res1) as $row1){
                    $data = array("row1" => $row1);
                    $this->load->view("vieworder", $data);


                }

            }
        } else {
            $flag = 1;
            $data = array("flag"=> $flag);
            $this -> load -> view("prelogin",$data); }
    }
}