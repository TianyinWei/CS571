<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Register extends CI_Controller
{
    public function __construct()
    {

        parent::__construct();
        session_start();
    }

    public function index()
    {

        $t = time();
        //including validation library

            if (($_SESSION['timeout'] + 300) < $t) {
                $flag = 2;
                $data = array("flag"=> $flag);
                $this -> load -> view("prelogin",$data);
                session_destroy();
            } else {


                $username = $this->input->post('username');
                $password = $this->input->post('pw');
                $firstname = $this->input->post('fname');
                $lastname = $this->input->post('lname');
                $addr = $this->input->post('addr');
                $zipcode = $this->input->post('zipcode');
                $card = $this->input->post('card');
                $expdate = $this->input->post('expdate');
                $security = $this->input->post('security');

                $userindex = "";

                $this->form_validation->set_error_delimiters('<p style="color:red">', '</p>');

                $this->form_validation->set_rules('username', 'username', 'required|min_length[4]|max_length[12]');
                $this->form_validation->set_rules('pw', 'password', 'required|min_length[4]|max_length[12]');
                $this->form_validation->set_rules('fname', 'firstname', 'required|callback_fnameRegex');
                $this->form_validation->set_rules('lname', 'lastname', 'required|callback_lnameRegex');
                $this->form_validation->set_rules('addr', 'address', 'required|callback_addrRegex');
                $this->form_validation->set_rules('zipcode', 'zipcode', 'required');
                $this->form_validation->set_rules('card', 'cardnumber', 'required');
                $this->form_validation->set_rules('expdate', 'expirationdate', 'required');
                $this->form_validation->set_rules('security', 'securitynumber', 'required');
                if ($this->form_validation->run() == FALSE){
                    $this->load->view("registerinfo");
                }else{

                $this->load->model("Register_model");
                $row2 = $this->Register_model->getuname($username);
                if (!isset($row2['username'])) {



                    $res1 = $this->Register_model->insertcustomer($username, $password, $firstname, $lastname, $addr, $zipcode, $card, $expdate, $security);
                    $data = array("res1" => $res1);
                    $this->load->view("Postregister", $data);}

                } else {
                    $flag = 1;
                    $data = array("flag" => $flag);
                    $this->load->view("registerinfo", $data);


                }
            }



        }

    public function fnameRegex($firstname) {
        if (preg_match('/[^a-zA-Z\s]/',$firstname)) {
            $this->form_validation->set_message('fnameRegex', 'firstname can only have letters and space!');

            return FALSE;
    } else {
            return TRUE;
        }
    }

    public function lnameRegex($lastname) {
        if (preg_match('/[^a-zA-Z\s]/',$lastname)) {
            $this->form_validation->set_message('lnameRegex', 'lastname can only have letters and space!');

            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function addrRegex($addr) {
        if (preg_match('/[^a-zA-Z0-9\s]/',$addr)) {
            $this->form_validation->set_message('addrRegex', 'address can only have letters,numbers and space!');

            return FALSE;
        } else {
            return TRUE;
        }
    }

}
