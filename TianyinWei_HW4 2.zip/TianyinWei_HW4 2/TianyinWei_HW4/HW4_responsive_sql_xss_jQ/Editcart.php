<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Editcart extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        session_start();

    }
    public function index()
    {
        $t = time();
        if ($_SESSION['customer']) {

            if (($_SESSION['timeout'] + 180) < $t) {
                $flag = 2;
                $data = array("flag"=> $flag);
                $this -> load -> view("prelogin",$data);
                session_destroy();
            } else {

                $edit = $_POST['editcart'];
                $cartindex = "'" . $_POST['cartindex'] . "'";
                $quantity = "'" . $_POST['quantity'] . "'";
                $customer = "'" . $_SESSION['customer'] . "'";

               $this -> load -> model("Editcart_model");

                $flag = 4;
                $data = array("flag" => $flag);
                $this->load->view("Cart.html", $data);


                if ($edit == 'Confirm Change') {
                    $res = $this -> Editcart_model -> changeqty($quantity,$cartindex);
                    if ($res) {

                        $row4 = $this -> Editcart_model -> totalprice($customer);
                        $row44 =  $this -> Editcart_model -> totalqty($customer);
                        $resbug = $this -> Editcart_model -> getcart($customer);

                        //while ($row = $this -> Editcart_model -> getrow($resbug)) {
                        foreach($this -> Editcart_model -> getrow($resbug) as $row){
                            $row2 = $this -> Editcart_model -> getproduct($row['productID']);
                            $data['row'] = $row;
                            $data['row2'] = $row2;
                            $this->load->view("presentcart", $data);
                        }


                        $subtotal = round($row4["SUM(price*quantity)"], 2);
                        $data = array("subtotal" => $subtotal, "row44" => $row44,"row4"=>$row4);
                        $this->load->view("cart_subtotal", $data);

                    }
                }

                if ($edit == 'Delete this item') {

                    $res = $this -> Editcart_model -> delcart($cartindex);
                    if ($res) {

                        $row4 = $this -> Editcart_model -> totalprice($customer);
                        $row44 =  $this -> Editcart_model -> totalqty($customer);
                        $resbug = $this -> Editcart_model -> getcart($customer);

                        //while ($row = $this -> Editcart_model -> getrow($resbug)) {
                          foreach($this -> Editcart_model -> getrow($resbug) as $row){
                            $row2 = $this -> Editcart_model -> getproduct($row['productID']);

                            $data['row'] = $row;
                            $data['row2'] = $row2;
                            $this->load->view("presentcart", $data);

                        }
                        $subtotal = round($row4["SUM(price*quantity)"], 2);
                        $data = array("subtotal" => $subtotal, "row44" => $row44,"row4"=>$row4);
                        $this->load->view("cart_subtotal", $data);
                    }
                }

                if ($edit == 'Clear shopping cart') {

                    $res = $this -> Editcart_model -> clearcart($customer);
                    $data = array("res"=>$res);
                    $this -> load -> view("clearcart",$data);

                }
            }
        } else {
            $flag = 1;
            $data = array("flag"=> $flag);
            $this -> load -> view("prelogin",$data);

        }
    }
}