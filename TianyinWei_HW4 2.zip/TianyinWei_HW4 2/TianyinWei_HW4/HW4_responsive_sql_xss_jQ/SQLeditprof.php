<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class SQLeditprof extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        session_start();
    }

    public function index()
    {

        $t = time();
        if ($_SESSION['customer']) {

            if (($_SESSION['timeout'] + 180) < $t) {
                $flag = 2;
                $data = array("flag"=> $flag);
                $this -> load -> view("prelogin",$data);
                session_destroy();
            } else {


                $pw = "'" . $_POST['pw'] . "'";
                $fname = "'" . $_POST['fname'] . "'";
                $lname = "'" . $_POST['lname'] . "'";
                $addr = "'" . $_POST['addr'] . "'";
                $zipcode = "'" . $_POST['zipcode'] . "'";
                $card = "'" . $_POST['card'] . "'";
                $expdate = "'" . $_POST['expdate'] . "'";
                $security = $_POST['security'];

                $customerID = "'" . $_POST['customerID'] . "'";
                $this->form_validation->set_error_delimiters('<p style="color:red">', '</p>');

                $this->form_validation->set_rules('username', 'username', 'required|min_length[4]|max_length[12]');
                $this->form_validation->set_rules('pw', 'password', 'required|min_length[4]|max_length[12]');
                $this->form_validation->set_rules('fname', 'firstname', 'required|callback_fnameRegex');
                $this->form_validation->set_rules('lname', 'lastname', 'required|callback_lnameRegex');
                $this->form_validation->set_rules('addr', 'address', 'required|callback_addrRegex');
                $this->form_validation->set_rules('zipcode', 'zipcode', 'required');
                $this->form_validation->set_rules('card', 'cardnumber', 'required');
                $this->form_validation->set_rules('expdate', 'expirationdate', 'required');
                $this->form_validation->set_rules('security', 'securitynumber', 'required');
                if ($this->form_validation->run() == FALSE){
                    $flag = 9;
                    $data = array("flag"=>$flag);
                    $this->load->view("Cart.html");
                }else {

                    $this->load->model("Editprofile_model");
                    $res = $this->Editprofile_model->updateprof($pw, $fname, $lname, $addr, $zipcode, $card, $expdate, $security,
                        $customerID);


                    if ($res) {
                        $flag = 3;
                        $data = array("flag" => $flag);
                        $this->load->view("prelogin", $data);

                    }
                }
            }
        } else {
            $flag = 1;
            $data = array("flag"=> $flag);
            $this -> load -> view("prelogin",$data);
        }
    }
    public function fnameRegex($firstname) {
        if (preg_match('/[^a-zA-Z\s]/',$firstname)) {
            $this->form_validation->set_message('fnameRegex', 'firstname can only have letters and space!');

            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function lnameRegex($lastname) {
        if (preg_match('/[^a-zA-Z\s]/',$lastname)) {
            $this->form_validation->set_message('lnameRegex', 'lastname can only have letters and space!');

            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function addrRegex($addr) {
        if (preg_match('/[^a-zA-Z0-9\s]/',$addr)) {
            $this->form_validation->set_message('addrRegex', 'address can only have letters,numbers and space!');

            return FALSE;
        } else {
            return TRUE;
        }
    }
}