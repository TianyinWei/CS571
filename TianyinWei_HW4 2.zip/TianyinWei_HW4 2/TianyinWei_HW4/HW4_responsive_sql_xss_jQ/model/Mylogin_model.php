<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Mylogin_model extends CI_Model{



    public function getunamepw($un,$pw){
        $sql = "select * from customer where username=?and password=?";
        $res = $this -> db -> query($sql,array($un,$pw));
        return $res;
    }

    public function getrow($param){
        $row = $param -> result_array();
        return $row;
    }

}
