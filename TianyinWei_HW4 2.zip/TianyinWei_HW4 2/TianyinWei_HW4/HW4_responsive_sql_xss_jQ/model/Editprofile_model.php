<?php  if(!defined('BASEPATH'))exit('No direct script access allowed');

class Editprofile_model extends CI_Model{


    public function getcustomer($customer){
        $res = $this -> db -> query("SELECT * FROM customer WHERE username=$customer");
        $row = $res -> row_array();
        return $row;
    }

    public function updateprof($pw,$fname,$lname,$addr,$zipcode,$card,$expdate,$security,$customerID){
        $res = $this -> db -> query("UPDATE customer SET password=$pw, firstname=$fname, lastname=$lname, address=$addr,
        zipcode=$zipcode,
cardnumber=$card, expdate=$expdate,securitycode=$security WHERE customerID=$customerID");
        return $res;
    }

}
