<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Showprod_model extends CI_Model{




    public function getcatnames(){
        $res = $this -> db -> query("SELECT * FROM ProdCategory");
        return $res;
    }

    public function getrow($param){
        //$row = mysql_fetch_assoc($param);
        $row = $param -> result_array();
        return $row;
    }

    public function getonerow($param){
        $row = $param -> row_array();
        return $row;
    }

    public function getproduct(){
        $res2 = $this -> db -> query("SELECT * FROM Product WHERE prodcategoryID=1");
        return $res2;
    }

    public function getspecialsales($param)
    {
        $res3 = $this -> db -> query("SELECT * FROM SpecialSales WHERE productID=$param");
        return $res3;
    }

    public function choosecatname($param)
    {
        $res1 = $this -> db -> query("SELECT * FROM ProdCategory WHERE prodcategoryname=$param");
        $row1 = $res1 -> row_array();
        return $row1;
    }

    public function getcatID($param)
    {
        $res2 = $this -> db -> query("SELECT * FROM Product WHERE prodcategoryID=$param");
        return $res2;
    }

}