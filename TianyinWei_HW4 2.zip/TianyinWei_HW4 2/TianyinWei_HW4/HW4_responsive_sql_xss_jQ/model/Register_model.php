<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Register_model extends CI_Model
{




    public function getuname($param)
    {
        $sql2 = "SELECT * FROM customer WHERE username=?";
        $res2 = $this -> db -> query($sql2,array($param));
        $row2 = $res2 -> row_array();
        return $row2;

    }

    public function getrow($param)
    {
        $row = $param -> row_array();
        return $row;
    }

    public function insertcustomer($username,$password,$firstname,$lastname,$addr,$zipcode,$card,$expdate,$security)
    {
        /*$sql1 = "INSERT INTO customer(username,password,firstname,lastname,address,zipcode,cardnumber,expdate,
        securitycode)VALUES
($username,$password,$firstname,$lastname,$addr,$zipcode,$card,$expdate,$security)";
        $res1 = $this -> db -> query($sql1,array());*/
        $sql1 = "INSERT INTO customer(username,password,firstname,lastname,address,zipcode,cardnumber,expdate,
        securitycode)VALUES
(?,?,?,?,?,?,?,?,?)";
        $res1 = $this -> db -> query($sql1,array($username,$password,$firstname,$lastname,$addr,$zipcode,$card,
            $expdate,$security));
        return $res1;
    }
}
