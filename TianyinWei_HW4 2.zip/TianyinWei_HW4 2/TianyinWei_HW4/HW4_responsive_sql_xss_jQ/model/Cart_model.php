<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Cart_model extends CI_Model{

    public function addtocart($customer,$prodname,$prodID,$price,$quantity,$catID)
    {
        $sql1 = "INSERT INTO cart(username,prodname,productID,price,quantity,catID)VALUES ($customer,$prodname,$prodID,
$price,$quantity,$catID)";
        $res1 = $this -> db -> query($sql1);
        return $res1;
    }
}