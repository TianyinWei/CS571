<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Viewcart_model extends CI_Model
{


    public function getcart($param){
        $res = $this -> db -> query("SELECT * FROM cart WHERE username=$param");
        return $res;

    }

    public function getrow($param){
        $row6 = $param -> result_array();
        return $row6;

    }

    public function getonerow($param){
        $row = $param -> row_array();
        return $row;
    }
    public function totalprice($param){
        $res4 = $this -> db -> query("SELECT SUM(price*quantity) FROM cart WHERE username=$param");
        $row4 = $res4 -> row_array();
        return $row4;
    }

    public function totalqty($param){
        $res44 = $this -> db -> query("SELECT SUM(quantity) FROM cart WHERE username=$param");
        //$row44 = mysql_fetch_assoc($res44);
        $row44 = $res44 -> row_array();
        return $row44;
    }

    public function getproduct($param){
        $res2 = $this -> db -> query("SELECT * FROM Product WHERE productID=$param");
        $row2 = $res2 -> row_array();;
        return $row2;
    }
}