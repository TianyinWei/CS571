<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Viewdetail_model extends CI_Model
{



    public function getsales($param)
    {
        $sql1 = "SELECT * FROM SpecialSales WHERE productID=?";
        $res1 = $this -> db -> query($sql1,array($param));
        $row1 = $res1 -> row_array();
        return $row1;
    }
    public function getproduct($param)
    {
        $sql2 = "SELECT * FROM Product WHERE productID=?";
        $res2 = $this -> db -> query($sql2,array($param));
        $row2 = $res2 -> row_array();
        return $row2;
    }
}