<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Precheck_model extends CI_Model
{


    public function getcart($param){
        $res = $this -> db -> query("SELECT * FROM cart WHERE username=$param");
        return $res;

    }

    public function getrow($param){
        $row6 = $param -> result_array();
        return $row6;

    }

    public function getcustomer($customer)
    {
        $sql2 = "SELECT * FROM customer WHERE username=$customer";
        $res2 = $this -> db -> query($sql2);
        $row2 = $res2 -> row_array();
        return $row2;
    }



    public function getproduct($param){
        $res2 = $this -> db -> query("SELECT * FROM Product WHERE productID=$param");
        $row2 = $res2 -> row_array();
        return $row2;
    }
}