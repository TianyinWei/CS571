<?php  if(!defined('BASEPATH'))exit('No direct script access allowed');

class Orderdetail_model extends CI_Model{


    public function selorderitem($orderid){
        $res2 = $this -> db -> query("SELECT * FROM orderitem WHERE orderID=$orderid");
        return $res2;
    }

    public function getrow($param){
        $row6 = $param -> result_array();
        return $row6;
    }

    public function selorderinfo($orderid){
        $res1 = $this -> db -> query("SELECT * FROM orderinfo WHERE orderID=$orderid");
        $row1 = $res1 -> row_array();
        return $row1;
    }

    public function selproduct($prodID){
        $res3 = $this -> db -> query("SELECT * FROM Product WHERE productID=$prodID");
        $row3 = $res3 -> row_array();
        return $row3;
    }

}
