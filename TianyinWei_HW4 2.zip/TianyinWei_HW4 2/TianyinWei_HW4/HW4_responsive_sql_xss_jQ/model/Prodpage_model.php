<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Prodpage_model extends CI_Model{




    public function getcatnames(){
        $res = $this -> db -> query("SELECT * FROM ProdCategory");
        return $res;
    }

    public function getrow($param){
        //$row = mysql_fetch_assoc($param);
        $row = $param->result_array();

        return $row;
    }

    public function getonerow($param){
        $row = $param -> row_array();
        return $row;
        }
    public function getproduct(){
        $res2 = $this -> db -> query("SELECT * FROM Product WHERE prodcategoryID=1");
        return $res2;
    }

    public function getspecialsales($param)
    {
        $res3 = $this -> db -> query("SELECT * FROM SpecialSales WHERE productID=$param");
        return $res3;
    }

}