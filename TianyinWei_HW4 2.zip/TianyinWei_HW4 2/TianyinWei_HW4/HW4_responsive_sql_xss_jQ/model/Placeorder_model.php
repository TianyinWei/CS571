<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Placeorder_model extends CI_Model
{




    public function getcustomer($customer){
        $sql0 = "SELECT * FROM customer WHERE username=$customer";
        $res0 = $this -> db -> query($sql0);
        $row0 = $res0 -> row_array();
        return $row0;
    }

    public function getrow($param){
        $row6 = $param -> result_array();
        return $row6;

    }

    public function totalprice($param){
        $res4 = $this -> db -> query("SELECT SUM(price*quantity) FROM cart WHERE username=$param");
        $row4 = $res4 -> row_array();
        return $row4;
    }

    public function totalqty($param){
        $res44 = $this -> db -> query("SELECT SUM(quantity) FROM cart WHERE username=$param");
        $row44 = $res44 -> row_array();
        return $row44;
    }

    public function getproduct($param){
        $res2 = $this -> db -> query("SELECT * FROM Product WHERE productID=$param");
        $row2 = $res2 -> row_array();
        return $row2;
    }

    public function addtoorderinfo($customer,
$totalmoney,$totalqty,$fname,$lname,$addr,$zipcode)
{
$res5 = $this -> db -> query("INSERT INTO orderinfo(orderID,username,totalprice,totalqty,firstname,lastname,address,zipcode,orderdate)VALUE
(null,$customer,$totalmoney,$totalqty,$fname,$lname,$addr,$zipcode,CURDATE())") or die(mysql_error());
    return $res5;
}

    public function getcart($customer){
        $res6 = $this -> db -> query("SELECT * FROM cart WHERE username=$customer");
        return $res6;
    }

    public function updatestorage($newstorage,$prodID){
        $res8 = $this -> db -> query("UPDATE Product SET storage=$newstorage WHERE productID=$prodID");
        return $res8;
    }

    public function lastinsert(){
        $res11 = $this -> db -> query("SELECT last_insert_id() FROM orderinfo");
        $row11 = $res11 -> row_array();
        return $row11;
    }

    public function addtoorderitem($last,$customerID,$customer,$prodname,$prodID,$catID,$price,$quantity){
        $res10 = $this -> db -> query("INSERT INTO orderitem(orderID,customerID,username,prodname,productID,catID,price,
    quantity)VALUES($last,$customerID,$customer,$prodname,$prodID,$catID,$price,$quantity)");
        return $res10;
    }

    public function delcart($customer){
        $res9 = $this -> db -> query("DELETE FROM cart WHERE username=$customer");
        return $res9;
    }

    public function selorderinfo($customer){
        $bug = $this -> db -> query("SELECT * FROM orderinfo WHERE username=$customer");
        $rowbug = $bug -> row_array();
        return $rowbug;
    }
}