<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Homepage_model extends CI_Model{

    public function salelist(){
        $res3 = $this -> db -> query("SELECT * FROM SpecialSales");
        return $res3;
    }

    public function productlist($param){
        $sql2 = "SELECT * FROM Product WHERE productID=$param";
        //$res2 = mysql_query($sql2);
        $res2 = $this -> db -> query($sql2);
        $row2 = $res2 -> row_array();
        return $row2;
    }
    public function getrow($param)
    {
        $row = $param->result_array();
        //$row = mysql_fetch_assoc($param);
        return $row;
    }

    /*public function __construct(){
        parent::__construct();
        $con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
        if (!$con) {
            die("connection fail");
        }

        mysql_select_db('mydatabase', $con);

    }*/

}
