<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Viewdetail extends CI_Controller
{
    public function __construct()

    {
        parent::__construct();
        session_start();
    }

    public function index()
    {
        if ($_SESSION['customer']) {
            $t = time();
            if (($_SESSION['timeout'] + 180) < $t) {
                $flag = 2;
                $data = array("flag"=> $flag);
                $this -> load -> view("prelogin",$data);
                session_destroy();
            } else {

                //$prodID = $_POST['productID'];
                $prodID = $this -> input -> post('productID');
                $this -> load -> model("Viewdetail_model");

                date_default_timezone_set('America/Los_Angeles');
                $today = date("Y-m-d"); // ("Y-m-d H:i:s") - DateTime

                $row1 = $this -> Viewdetail_model -> getsales($prodID);
                $enddate = $row1['enddate'];


                $row2 = $this -> Viewdetail_model -> getproduct($prodID);


                $flag = 1;
                $data = array("flag"=>$flag);
                $this -> load -> view("Cart.html",$data);

                if ($enddate >= $today) {
                    $data['row2']=$row2;
                    $data['row1']=$row1;
                    $this -> load -> view("detail_sale",$data);

                    $_SESSION['cartprodname'] = "'" . $row2['prodname'] . " '";
                    $_SESSION['cartprodprice'] = "'" . $row1['price'] . " '";

                } else {


                    $data['row2']=$row2;
                    $data['row1']=$row1;

                    $this -> load -> view("detail_nosale",$data);

                    $_SESSION['cartprodname'] = "'" . $row2['prodname'] . " '";
                    $_SESSION['cartprodprice'] = "'" . $row2['prodprice'] . " '";

                }


            }
        }else {
            $flag = 1;
            $data = array("flag"=> $flag);
            $this -> load -> view("prelogin",$data);

        }
    }
}