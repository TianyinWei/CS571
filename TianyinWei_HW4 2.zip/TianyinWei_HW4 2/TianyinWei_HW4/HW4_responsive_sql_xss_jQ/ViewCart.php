<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class ViewCart extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        session_start();

    }

    public function index()
    {
        $t = time();
        if ($_SESSION['customer']) {

            if (($_SESSION['timeout'] + 180) < $t) {
                $flag = 2;
                $data = array("flag"=> $flag);
                $this -> load -> view("prelogin",$data);
                session_destroy();
            } else {

                $customer = "'" . $_SESSION['customer'] . "'";

                $this -> load -> model("Viewcart_model");

                $res = $this -> Viewcart_model -> getcart($customer);
                $row6 = $this -> Viewcart_model -> getonerow($res);
                $resbug = $this -> Viewcart_model -> getcart($customer);

                $row4 = $this -> Viewcart_model -> totalprice($customer);
                $row44 =  $this -> Viewcart_model -> totalqty($customer);

                $flag = 3;
                $data = array("flag" => $flag,"row6" => $row6);
                $this->load->view("Cart.html", $data);

                if ($row6) {
                    //while ($row = $this -> Viewcart_model -> getrow($resbug)) {
                    foreach ($this -> Viewcart_model -> getrow($resbug)as $row){
                        $row2 = $this -> Viewcart_model -> getproduct($row['productID']);
                        $data['row'] = $row;
                        $data['row2'] = $row2;
                        $this->load->view("presentcart", $data);
                    }
                    $subtotal = round($row4["SUM(price*quantity)"], 2);
                    $data = array("subtotal" => $subtotal, "row44" => $row44,"row4"=>$row4);
                    $this->load->view("cart_subtotal", $data);


                }

            }
        } else {
            $flag = 1;
            $data = array("flag"=> $flag);
            $this -> load -> view("prelogin",$data); }
    }
}