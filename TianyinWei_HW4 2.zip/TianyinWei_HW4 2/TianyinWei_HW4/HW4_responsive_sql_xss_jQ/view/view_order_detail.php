<?php
echo '<div class="adduser-card-1">';

echo '<table>
                <tr>
                    <th>OrderID</th>
                    <th>Name</th>
                    <th>Shipped to</th>
                    <th>Product name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Product view</th>
                </tr>';
echo '<tr>';
echo "<td>".$row1['orderID']."</td>";
echo "<td>" . $row1['firstname'] . "" . $row1['lastname'] . "</td>";
echo "<td><p>" . $row1['address'] . "</p><p>" . $row1['zipcode'] . "</p></td>";
echo "<td>" . $row2['prodname'] . "</td>";
echo "<td>$" . $row2['price'] . "</td>";
echo "<td>" . $row2['quantity'] . "</td>";
echo '<td><img src="' . $row3['prodimg'] . '" alt="' . $row2['prodimg'] . '" height="150" width="200"></td>';
echo '</tr></table></div>';

echo '<div class="adduser-card-2">';

echo '<table>';

echo "<tr><td>OrderID:".$row1['orderID']."</td></tr>";
echo "<tr><td>Name:" . $row1['firstname'] . "" . $row1['lastname'] . "</td></tr>";
echo "<tr><td><p>Shipped to:" . $row1['address'] . "</p><p>" . $row1['zipcode'] . "</p></td></tr>";
echo "<tr><td>Product name:" . $row2['prodname'] . "</td></tr>";
echo "<tr><td>Price:$" . $row2['price'] . "</td></tr>";
echo "<tr><td>Quantity:" . $row2['quantity'] . "</td></tr>";
echo '<tr><td>Product view:<img src="' . $row3['prodimg'] . '" alt="' . $row2['prodimg'] . '" height="150" width="200"></td></tr>';
echo '</table></div>';

?>