<?php
echo '<div class="adduser-card">';
echo '<img src="' . $row3['prodimg'] . '" alt="' . $row3['prodimg'] . '" height="200" width="250">';

echo '<p>' . $row1['prodname'] . '</p>';
echo '<p>Price:$' . $row1['price'] . '</p>';
echo '<p>Quantity:' . $row1['quantity'] . '</p>';
echo '<input type="hidden" name="cartindex" value="' . $row1['cartindex'] . '"></div>';
?>