<?php
echo '<div class="adduser-card" id="div7">';
echo '<table>';
echo '<form action="Orderdetail" method="post">';
echo '<tr>';
echo "<td >OrderID:" .$row1['orderID']. "</td>";
echo "<td >Orderdate:" .$row1['orderdate']. "</td>";
echo "<td >Total price:$" .$row1['totalprice']. "</td>";
echo "<td >Total quantity:" .$row1['totalqty']. "</td>";
echo '<td
><input type="submit"   class="vieworderdetail" name="vieworderdetail"
value="View order detail"></td>';

echo '</tr>';
echo '<input type="hidden"  name="orderID" value="'.$row1['orderID'].'">';
echo '</form></table></div>';

echo '<div class="adduser-card" id="div8">';
echo '<table>';
echo '<form action="Orderdetail" method="post">';
echo '<tr>';
echo "<tr><td >OrderID:" .$row1['orderID']. "</td></tr>";
echo "<tr><td >Orderdate:" .$row1['orderdate']. "</td></tr>";
echo "<tr><td >Total price:$" .$row1['totalprice']. "</td></tr>";
echo "<tr><td >Total quantity:" .$row1['totalqty']. "</td></tr>";
echo '<td
><input type="submit"  class="vieworderdetail" name="vieworderdetail"
value="View order detail"></td>';

echo '</tr>';
echo '<input type="hidden"  name="orderID" value="'.$row1['orderID'].'">';
echo '</form></table></div>';


?>