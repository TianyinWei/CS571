<html>
<head>
<style>
body {
    background-image: url("/HW3/background2.png");
    background-repeat:no-repeat; 
  background-size:cover;

}
.adduser-card {
  padding: 60px;
  width: 300px;
  background-color: #F7F7F7;
  margin: 0 auto 10px;
  border-radius: 20px;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  overflow: hidden;
}

.adduser-card h1 {
  font-weight: 10;
  text-align: center;
  font-size: 1.5em;
}

.add {
  text-align: center;
  font-size: 14px;
  font-family: 'Arial', sans-serif;
  font-weight: 700;
  height: 36px;
  padding: 0 8px;
/* border-radius: 3px; */
/* -webkit-user-select: none;
  user-select: none; */
}

.add-submit {
  /* border: 1px solid #3079ed; */
  border: 0px;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1); 
  background-color: #9f35ff;
  /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#4787ed)); */
}

.add-submit:hover {
  /* border: 1px solid #2f5bb7; */
  border: 0px;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #be77ff;
  /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#357ae8)); */
}

  
</style>
    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
    <script type="text/javascript">

       $(document).ready(validateForm);
       function validateForm() {$("#regInfo").submit(checkFormat);}

        function checkFormat(){
            var VALfname = $("#fname").val();
            var VALlname = $("#lname").val();
            var VALaddr = $("#addr").val();

            var errfname = $("#errfname");
            var errlname = $("#errlname");
            var erraddr = $("#erraddr");

            var fname = new RegExp(/[^a-zA-Z\s]/);
            var lname = new RegExp(/[^a-zA-Z\s]/);
            var addr = new RegExp(/[^a-zA-Z0-9\s]/);
            if (fname.test(VALfname)) {
                errfname.html("only letters and space");
            }
            if (lname.test(VALlname)) {
                errlname.html("only letters and space");
            }
            if (addr.test(VALaddr)) {
                erraddr.html("only letters,numbers and space");
            }
            if (!(fname.test(VALfname))){
                errfname.html("correct format");
            }
            if (!(lname.test(VALlname))) {
                errlname.html("correct format");
            }
            if (!(addr.test(VALaddr))) {
                erraddr.html("correct format");
            }


            if((fname.test(VALfname)) || (lname.test(VALlname)) || (addr.test(VALaddr))){return false;}
            if (!((fname.test(VALfname)) || (lname.test(VALlname)) || (addr.test(VALaddr)))) {return true;}
        }

    </script>
</head>

<body>
<b class="logout"><a href="Logout">Logout</a></b>

<div class="adduser-card">
<h1>Please fill out your information below </h1>
    <p style="color:darkviolet;text-align: center">All fields are required</p>
    <?php echo validation_errors(); ?>

    <form action="/CodeIgniter/index.php/Register" method="post" name="regInfo" id="regInfo">
  Username(4~12 chars):<input type="text" id="username" name="username" pattern=".{4,12}"  title="4 to 12 characters"
                              required/><br><br>

    Password(4~12 chars):<input type="text" id="pw" name="pw" pattern=".{4,12}"  title="4 to 12 characters" required/><br><br>
    Firstname:<input type="text" id="fname" name="fname"  required/><p id="errfname"
                                                                                              style="display:inline;color:red"></p><br><br>
    Lastname:<input type="text" id="lname" name="lname" required/><p id="errlname"
                                                                                             style="display:inline;color:red"></p><br><br>
    Shipping address: <input type="text" id="addr" name="addr" size="40" required/><p id="erraddr"
                                                                                      style="display:inline;color:red"></p><br><br>
    Zipcode:<input type="text" id="zipcode" name="zipcode" pattern="[0-9]{5}" title="5-digit zipcode"
    required/><br><br>
    Card number:<input type="text" id="card" name="card"  pattern="[0-9]{16}"
                       title="16-digit card number" required/><br><br>
    Expiration date:<input type="month" id="exdate" name="expdate"  min="2015-07" required/><br><br>
    Security code:<input type="text" id="security" name="security"  pattern="[0-9]{3}"
                         title="3-digit security code"  required/><br><br>



    <input type="submit" id="register" name="submit" class="add add-submit" value="Register">

    <?php
        if(isset($flag)){
            echo '<p style="color:red">Username already exists!</p></form></div></body></html>';

        }?>