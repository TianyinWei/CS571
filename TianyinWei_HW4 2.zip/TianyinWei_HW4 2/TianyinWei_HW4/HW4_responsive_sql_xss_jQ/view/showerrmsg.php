<?php
echo '<p style="color:red">' . $errmsg . '</p>';
?>