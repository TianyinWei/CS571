<?php
if (!$res) {
                        echo "error in clearing my cart";
                    } else {
                        echo "Cart cleared up successfully!";
                    }
                    ?>