<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

echo '<form action="Viewdetail" method="POST" style="width:100%">';
echo '<tr>';
echo '<td id="tds"><img src="' . $row2['prodimg'] . '" alt="' . $row2['prodimg'] . '" style="height:200px;width:250px"></td>';
echo '<td id="tds"><p style="font-size: 1.3em">' . $row2['prodname'] . '</p></td>';
if ($enddate >= $today) {
    echo '<td id="tds"><p style="text-decoration: line-through">Original Price:$' . $row2['prodprice'] . '</p>';
    echo '<p style="color:blueviolet;font-size: 1.5em">Now:$' . $row3['price'] . '</p></td>';
    echo '<td id="tds"><p style="color:blueviolet;font-size:2em">ON SALE!!</p></td>';

} else {
    echo '<td id="tds"><p style="font-size:1.3em">Price:$' . $row2['prodprice'] . '</p></td>';
    echo '<td id="tds" ></td>';
}
echo '<td id="tds"><input type="submit"  class="add add-submit" name="viewdetail"
value="View product detail"></td>';

echo '</tr>';
echo '<input type="hidden" name="productID" value="' . $row2['productID'] . '" >';
echo '</form>';

?>