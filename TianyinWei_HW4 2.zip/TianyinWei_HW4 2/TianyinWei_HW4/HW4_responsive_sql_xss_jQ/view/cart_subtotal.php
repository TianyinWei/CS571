<?php
echo '<div class="adduser-card">';

echo '<p>Subtotal:$' . $subtotal . '</p>';
echo '<p>Total quantity:$' . $row44['SUM(quantity)'] . '</p>';
echo '<form action="Editcart" method="POST">';
echo '<input type="submit" class="add add-submit" name="editcart" value="Clear shopping cart"></form>';
echo '<br>';
echo '<form action="Precheckout" method="POST">';
echo '<input type="submit" class="add add-submit" name="editcart"
value="Proceed to Checkout"></form>';
echo '</div></body></html>';
?>