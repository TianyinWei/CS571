<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Home Page</title>
    <style>

    body {
        background-image: url("/HW3/background2.png");
        background-repeat: no-repeat;
        background-size: cover;

    }

    .adduser-card {
        padding: 20px;
        width: 300px;
        background-color: #F7F7F7;
        margin: 0 auto 10px;
        border-radius: 20px;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        overflow: hidden;
        box-sizing: border-box;
    }




    .adduser-card h1 {
                font-weight: 10;
                text-align: center;
                font-size: 1.5em;
            }

            h1 {
                font-weight: 100;
                text-align: center;
                font-size: 2.3em;
                color: #804040;
                text-shadow: 2px 2px 4px #aaaaff;
                font-style: italic;
                font-size: 40px;
                text-align: center;

            }

            h2 {
                font-weight: 80;
                text-align: center;
                font-size: 1.5em;
                color: #804040;
                text-shadow: 2px 2px 4px #aaaaff;
                font-style: italic;
                font-size: 35px;
                text-align: center;

            }

            .add {
                text-align: center;
                font-size: 14px;
                font-family: 'Arial', sans-serif;
                font-weight: 700;
                height: 36px;
                padding: 0 8px;
                /* border-radius: 3px; */
                /* -webkit-user-select: none;
                  user-select: none; */
            }

            .add-submit {
                /* border: 1px solid #3079ed; */
                border: 0px;
                color: #fff;
                text-shadow: 0 1px rgba(0, 0, 0, 0.1);
                background-color: #9f35ff;
                /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#4787ed)); */
            }

            .add-submit:hover {
                /* border: 1px solid #2f5bb7; */
                border: 0px;
                text-shadow: 0 1px rgba(0, 0, 0, 0.3);
                background-color: #be77ff;
                /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#357ae8)); */
            }

            .addtocart {
                text-align: right;
            }

            table {

                position: relative;
                left:5%;

            }


    </style>
</head>
<body>
<b class="logout" style="font-size: 1.2em;font-family: sans-serif"><a href="/CodeIgniter/index.php/Mylogin">For more fancy foods,
        please Sign in HERE</a></b>


<h1 style="position:relative;top:.2in">Fun with Eating!</h1>


<h2>Special Sales</h2>
