<?php

echo '<table style="width:100%">';
?>