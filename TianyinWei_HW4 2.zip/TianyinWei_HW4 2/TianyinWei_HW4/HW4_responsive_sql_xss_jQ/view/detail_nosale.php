<?php
echo '<form action="Cart" method="POST">';
echo '<div class="adduser-card">';
echo '<img src="' . $row2['prodimg'] . '" alt="' . $row2['prodimg'] . '" height="200" width="250"><br>';
echo '<p>' . $row2['prodname'] . '</p>';
echo '<p>' . $row2['proddescription'] . '</p>';
echo '<p>Price:$' . $row2['prodprice'] . '</p>';
echo '<p>In stock:' . $row2['storage'] . '</p>';
echo 'Quantity you want:<input type="number" name="quantity" min="1" max="' . $row2['storage'] . '" required/><br>';
echo '<input type="hidden" name="productID" value="' . $row2['productID'] . '">';
echo '<input type="hidden" name="catID" value="' . $row2['prodcategoryID'] . '">';

echo '<input type="submit"  class="add add-submit" name="addtocart" value="Add to cart">';
echo '</div></form></body></html>';
?>