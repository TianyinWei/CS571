<?php
echo '<td style="float:left">';

                echo '<div class="adduser-card">';
                echo '<form action="viewdetail.php" method="POST">';
                echo '<img src="' . $row2['prodimg'] . '" alt="' . $row2['prodimg'] . '" height="200" width="230"><br>';
                echo '<p style="font-size: 1.3em">' . $row2['prodname'] . '</p>';
                echo '<p style="text-decoration: line-through">Original Price:$' . $row2['prodprice'] . '</p>';
                echo '<p style="font-size: 1.5em;color:blueviolet">Now:$' . $row3['price'] . '</p>';
                echo '<input type="hidden" name="productID" value="' . $row3['productID'] . '" >';
                //echo '<input type="submit"  class="add add-submit" name="viewdetail" value="View product detail">';
                echo '</form></div></td>';
                ?>