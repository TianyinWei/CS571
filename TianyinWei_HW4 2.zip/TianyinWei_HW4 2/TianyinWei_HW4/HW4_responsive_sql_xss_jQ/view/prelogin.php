<html >
  <head>
        <title>Log-in</title>

        <link rel="stylesheet" href="/HW3/style.css">


  </head>

  <body>
    <div class="login-card" style=" padding: 5% 5%;width: 20%;left:40%">
    <h1>Fun with Eating</h1><br>
<form method="post" action="/CodeIgniter/index.php/Mylogin">
    <input type="text" name="username" placeholder="username" id="username">
    <input type="password" name="pw" placeholder="******" id="pw">
    <input type="submit" name="submit" class="login login-submit" value="login">
	<input type="submit" name="submit" class="login login-submit" value="New member?Register NOW!">

    <?php
        if($flag==1){
            echo '<p style="font-size:25px;color:red">Please log in first!</p></form></div></body></html>';

        }
        if ($flag == 2){
            echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p></form></div></body></html>';
        }

        if($flag == 3){
            echo '<p style="font-size:25px;color:red">Now you have edited your personal profile. Please log in !</p>';
            echo '</div></body></html>';
        }