<?php
echo '<div class="adduser-card">';
echo '<p style="font-size:1.5em">Ship to:(you can edit shipping info below)</p>';
echo 'Firstname:<input type="text" name="fname" id="fname" value="' . $row2['firstname'] . '"
 required><p id="errfname" style="display:inline;color:red"></p><br><br>';
echo 'Lastname:<input type="text" name="lname" id="lname" value="' . $row2['lastname'] . '"
 required><p id="errlname" style="display:inline;color:red"></p><br><br>';
echo 'Address:<input type="text" name="addr" id="addr" value="' . $row2['address'] . '"
 required><p id="erraddr" style="display:inline;color:red"></p><br><br>';
echo 'Zipcode:<input type="text" name="zipcode" pattern="[0-9]{5}" title="5-digit zipcode" value="' . $row2['zipcode'] . '"
/required><br>';

echo '<input type="submit" class="add add-submit" name="placeorder" value="Ship to this address">';
echo '</div>';

echo '</form></body></html>';
?>