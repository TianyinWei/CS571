<?php
echo '<table>';
echo '<tr>';
?>