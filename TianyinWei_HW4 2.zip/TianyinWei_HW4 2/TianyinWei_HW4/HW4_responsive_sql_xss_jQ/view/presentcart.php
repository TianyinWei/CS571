<?php
echo '<div class="adduser-card">';
echo '<form action="Editcart" method="POST">';
echo '<img src="' . $row2['prodimg'] . '" alt="' . $row2['prodimg'] . '" height="120" width="120"><br>';
echo '<p>' . $row['prodname'] . '</p>';
echo '<p>Price:$' . $row['price'] . '</p>';
echo '<input type="hidden" name="productID" value="' . $row['productID'] . '">';
echo '<input type="hidden" name="catID" value="' . $row['catID'] . '">';
echo '<input type="number" name="quantity" value="' . $row['quantity'] . '" min="1" max="'.$row2['storage']
    .'" ><br><br>';
echo '<input type="hidden" name="cartindex" value="' . $row['cartindex'] . '">';
// print_r($row['cartindex']);
echo '<input type="submit"  class="add add-submit" id="chgitem" name="editcart"
value="Confirm Change">';
echo '<span id="spanchgdelitem" style="position:relative"><input type="submit"  class="add add-submit" id="delitem"
name="editcart"
value="Delete this item"></span></form></div>';
?>
