<?php

echo '<input type="submit" class="add" style="width:10%;left:10%" name="choosecat" value="'
    . $row4['prodcategoryname'] . '"><span id="spancatnames">';
?>