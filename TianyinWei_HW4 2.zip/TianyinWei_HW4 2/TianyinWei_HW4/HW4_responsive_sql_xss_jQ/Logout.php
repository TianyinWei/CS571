<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Logout extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        session_start();
    }

    public function index()
    {
        if (session_destroy()) // Destroying All Sessions
        {
            header("Location: Homepage"); // Redirecting To Home Page
        }
    }
}