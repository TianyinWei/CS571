<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Homepage extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        session_start();
    }

    public function index()
    {

        $row = 0;

       date_default_timezone_set('America/Los_Angeles');
        $today = date("Y-m-d"); // ("Y-m-d H:i:s") - DateTime

       // require 'Homepage.html';
        // echo '<table>';
        $this -> load -> view('Homeview');
        $this -> load -> view('echotable');
        $this -> load -> model("Homepage_model");
        $res3 = $this -> Homepage_model -> salelist();
        //while ($row3 = $res3->result_array()){
        //while ($row3 = $this -> Homepage_model -> getrow($res3)) {
        foreach($this -> Homepage_model -> getrow($res3) as $row3){
            //printf($row3['productID']);
           /* if (($row % 2) == 0) {
                //echo '<tr>';
                $this -> load -> view('echotr');
            }*/
            $enddate = $row3['enddate'];
            if ($enddate >= $today) {

                $row2 = $this -> Homepage_model -> productlist($row3['productID']);
                $data = array();
                $data['row2'] = $row2;
                $data['row3'] = $row3;

                /*echo '<td>';

                echo '<div class="adduser-card">';
                echo '<form action="viewdetail.php" method="POST">';
                echo '<img src="' . $row2['prodimg'] . '" alt="' . $row2['prodimg'] . '" height="200" width="230"><br>';
                echo '<p style="font-size: 1.3em">' . $row2['prodname'] . '</p>';
                echo '<p style="text-decoration: line-through">Original Price:$' . $row2['prodprice'] . '</p>';
                echo '<p style="font-size: 1.5em;color:blueviolet">Now:$' . $row3['price'] . '</p>';
                echo '<input type="hidden" name="productID" value="' . $row3['productID'] . '" >';
                //echo '<input type="submit"  class="add add-submit" name="viewdetail" value="View product detail">';
                echo '</form></div></td>';*/
                $this -> load -> view('homeproducts', $data);


                /*if (($row % 2) == 1) {
                 //   echo '</tr>';
                    $this -> load -> view('echoendtr');
                }
                $row = $row + 1;*/
            }

        }
      //  echo '</table></body></html>';
        $this -> load -> view('endhomeview');
       // mysql_close($con);


    }
}
