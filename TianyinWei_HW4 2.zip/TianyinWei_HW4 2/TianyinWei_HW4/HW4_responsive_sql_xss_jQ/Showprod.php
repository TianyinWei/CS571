<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Showprod extends CI_Controller{
    public function __construct()
    {
        parent::__construct();
        session_start();
    }

    public function index()
    {

        $t = time();
        if ($_SESSION['customer']) {

            if (($_SESSION['timeout'] + 180) < $t) {
                $flag = 2;
                $data = array("flag"=> $flag);
                $this -> load -> view("prelogin",$data);

                session_destroy();
            } else {
                $catname = "'".$_POST['choosecat']."'";
                $customer = $_SESSION['customer'];
                $data = array("customer"=>$customer);

                $this -> load -> model("Showprod_model");
                date_default_timezone_set('America/Los_Angeles');
                $today = date("Y-m-d"); // ("Y-m-d H:i:s") - DateTime


                $res4 = $this -> Showprod_model -> getcatnames();
                $this -> load -> view("prodpage.html",$data);

                //while ($row4 = $this -> Showprod_model -> getrow($res4)) {
               /* foreach ($this -> Showprod_model -> getrow($res4) as $row4){
                    $data = array('row4' => $row4);
                    $this -> load -> view("catnames",$data);
                }*/
                $this -> load -> view("spans");

                $row1 = $this -> Showprod_model -> choosecatname($catname);
                $categoryID = $row1['prodcategoryID'];

                $res2 = $this -> Showprod_model -> getcatID($categoryID);  //get product ID

                //while ($row2 = $this -> Showprod_model -> getrow($res2)) {
                foreach ($this -> Showprod_model -> getrow($res2) as $row2){

                    $res3 = $this -> Showprod_model -> getspecialsales($row2['productID']);
                    $row3 = $this -> Showprod_model -> getonerow($res3);
                    $enddate = $row3['enddate'];
                    $data = array("enddate"=>$enddate,"today"=>$today);
                    $data['row2'] = $row2;
                    $data['row3'] = $row3;
                    $this -> load -> view("viewdetail",$data);

                }

            }
        }  else {
        $flag = 1;
        $data = array("flag"=> $flag);
        $this -> load -> view("prelogin",$data);

    }
    }
}

