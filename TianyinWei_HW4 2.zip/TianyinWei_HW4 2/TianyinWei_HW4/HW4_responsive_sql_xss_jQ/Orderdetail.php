<?php if(!defined('BASEPATH'))exit('No direct script access allowed');

class Orderdetail extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        session_start();
    }


    public function index()
    {
        $t = time();
        if ($_SESSION['customer']) {

            if (($_SESSION['timeout'] + 180) < $t) {
                $flag = 2;
                $data = array("flag"=> $flag);
                $this -> load -> view("prelogin",$data);
                session_destroy();
            } else {

                $customer = "'" . $_SESSION['customer'] . "'";

                $this -> load -> model("Orderdetail_model");

                $orderid = $_POST['orderID'];
                $res2 = $this -> Orderdetail_model -> selorderitem($orderid);

                $flag = 8;
                $data = array("flag" => $flag);
                $this->load->view("Cart.html", $data);

               // while ($row2 = $this -> Orderdetail_model -> getrow($res2)) {
                foreach($this -> Orderdetail_model -> getrow($res2) as $row2){
                    $row1 = $this -> Orderdetail_model -> selorderinfo($orderid);
                    $prodID = "'" . $row2['productID'] . "'";

                    $row3 = $this -> Orderdetail_model -> selproduct($prodID);
                    $data['row1'] = $row1;
                    $data['row2'] = $row2;
                    $data['row3'] = $row3;
                    $this->load->view("view_order_detail", $data);

                }

            }
        } else {
            $flag = 1;
            $data = array("flag"=> $flag);
            $this -> load -> view("prelogin",$data);
        }
    }
}