<?php
/* calculate total price OK*/
/* insert into orderinfo OK*/
/* insert multiple items to orderitem OK*/
/* product table storage=storage-quantity OK*/
/* clear shopping cart of that customer OK*/
/* how to show date OK*/


session_start();
$t = time();
if ($_SESSION['customer']){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p></form></div></body></html>';

        session_destroy();
    }else{

$customer="'".$_SESSION['customer']."'";
$fname="'".$_POST['fname']."'";
$lname="'".$_POST['lname']."'";
$addr="'".$_POST['addr']."'";
$zipcode="'".$_POST['zipcode']."'";

$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);

//get customerID
$sql0 = "SELECT * FROM customer WHERE username=$customer";
$res0 = mysql_query($sql0);
$row0 = mysql_fetch_assoc($res0);
$customerID = $row0['customerID'];


/*generate date
date_default_timezone_set('America/Los_Angeles');
$today = date("Y-m-d"); // ("Y-m-d H:i:s") - DateTime
printf($today);*/

//caculate total price and quantity
$res4 = mysql_query("SELECT SUM(price*quantity) FROM cart WHERE username=$customer");
$row4 = mysql_fetch_assoc($res4);
$totalprice =$row4['SUM(price*quantity)'];
$res44 = mysql_query("SELECT SUM(quantity) FROM cart WHERE username=$customer");
$row44 = mysql_fetch_assoc($res44);
$totalqty =$row44['SUM(quantity)'];

$res5 = mysql_query("INSERT INTO orderinfo(orderID,orderdate,username,totalprice,totalqty,firstname,lastname,address,zipcode)VALUE (null,
CURDATE(),$customer,
$totalprice,$totalqty,$fname,$lname,$addr,$zipcode)")or die(mysql_error());

/*$res5 = mysql_query("INSERT INTO orderinfo(orderID,orderdate,username,totalprice,totalqty)VALUE (null,'2015-07-07',
$customer,$totalprice,$totalqty)")or die(mysql_error());*/


//substract storage in Product by order quantity
$res6 = mysql_query("SELECT * FROM cart WHERE username=$customer");
while ($row6 = mysql_fetch_assoc($res6)) {
    $prodID = $row6['productID'] ;
    $quantity = $row6['quantity'];
    $res7 = mysql_query("SELECT * FROM Product WHERE productID=$prodID");
    $row7 = mysql_fetch_assoc($res7);
    $storage =$row7['storage'];
    /*printf($storage);
    printf(",");
    printf($prodID);
    printf(",");
    printf($quantity);
    printf(",");*/
    $newstorage = $storage - $quantity;
    //printf($newstorage);
    //printf(",");
    $res8 = mysql_query("UPDATE Product SET storage=$newstorage WHERE productID=$prodID");
}



//isert multiple items to orderitem
$res11 = mysql_query("SELECT last_insert_id() FROM orderinfo");
$row11 = mysql_fetch_assoc($res11);
$last = $row11['last_insert_id()']; //get last insert ID

$res22 = mysql_query("SELECT * FROM cart WHERE username=$customer");
while ($row22=mysql_fetch_assoc($res22)) {
    //$customerID = "'".$row22['customerID']."'";
    $prodID = $row22['productID'];
    $prodname = "'" . $row22['prodname'] . "'";
    $catID = $row22['catID'];
    $price = $row22['price'];
    $quantity = $row22['quantity'];
   /* printf($prodID);
    printf(",");
    printf($prodname);
    printf(",");
    printf($catID);
    printf(",");
    printf($price);
    printf(",");
    printf($quantity);
    printf(",");
    printf($customerID);
    printf(",");
    printf($last);
    printf("........");*/
    $res10 = mysql_query("INSERT INTO orderitem(orderID,customerID,username,prodname,productID,catID,price,
    quantity)VALUES($last,$customerID,$customer,$prodname,$prodID,$catID,$price,$quantity)");
}

//delete corresponding shopping cart
$res9 = mysql_query("DELETE FROM cart WHERE username=$customer");
$bug = mysql_query("SELECT * FROM orderinfo WHERE username=$customer");
$rowbug=mysql_fetch_assoc($bug);
require "Cart.html";
echo '<div class="adduser-card">';
echo '<p>Your order is placed successfully!</p>';

echo '</div></body></html>';
mysql_close($con);
}
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p></form></div></body></html>';
}
?>