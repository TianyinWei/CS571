<?php
	session_start();
	$_SESSION['timeout'] = time();
	//print_r($_SESSION['timeout']);
	$un = $_POST['username'];
	$pw = $_POST['pw'];
	$errmsg = "";
	$usertype = "";
    $s = $_POST['submit'];
if ($s == 'New member?Register NOW!'){header("location:register.html");}

    if (strlen($un) == 0) {
        $errmsg = 'Please enter username';
    }
    if (strlen($pw) == 0) {
        $errmsg = 'Please enter password';
    }
    if (strlen($un) == 0 && strlen($pw) == 0) {
        $errmsg = "";
    }
    if (strlen($un) > 0 && strlen($pw) > 0) {
        $sql = "select * from customer where username='" . $un . "' and password='" . $pw . "'";
        $con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
        if (!$con) {
            die("connection fail");
        }
        mysql_select_db('mydatabase', $con);
        $res = mysql_query($sql);
        if (!($row = mysql_fetch_assoc($res))) {
            $errmsg = 'Username or password is invalid';
        } else {
           // $usertype = $row['usertype'];
        }
        mysql_close($con);
    }
    if (strlen($errmsg) > 0) {
        require 'prelogin.html';
        echo '<p style="color:red">' . $errmsg . '</p>';
        echo '</form></div></body></html>';
    } elseif (!$res) {
        require 'prelogin.html';
        echo '</form></div></body></html>';

    } else {
        header("location:prodpage.php");
        $_SESSION['customer'] = $un;
      //  $_SESSION['username'] = $username;

    }


?>