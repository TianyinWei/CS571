<?php
session_start();

$catID = $_POST['category'];
$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);

require "orderReport.html";
echo '<div class="orderdetail">';


$res = mysql_query("SELECT oi.productID,oi.quantity,oi.price,o.orderdate,p.prodname,p.prodimg,p.productID FROM  orderinfo as o, orderitem as
 oi,
Product as p WHERE oi.productID=p
.productID and p.prodcategoryID=$catID and oi.orderID=o.orderID");


echo '<table>';
echo '<tr>';
echo '<th>Product view</th>';
echo '<th>Product ID</th>';
echo '<th>Product name</th>';
echo '<th>Quantity sold</th>';
echo '<th>Price</th>';
echo '<th>Order date</th>';
echo '</tr>';
while ($row = mysql_fetch_assoc($res)) {
    $subtotal = round($row['price'],2);

    echo '<tr>';
    echo '<td><img src="' . $row['prodimg'] . '" alt="' . $row['prodimg'] . '" height="150" width="200"></td>';
    echo "<td>" . $row['productID'] . "</td>";
    echo "<td>" . $row['prodname'] . "</td>";
    echo "<td>" . $row['quantity'] . "</td>";
    echo "<td>$" . $subtotal . "</td>";
    echo "<td>" . $row['orderdate'] . "</td>";
    echo '</tr>';
}
echo '</table>';

echo '</div></body></html>';

mysql_close($con);
?>