<?php

session_start();
$t = time();
if ($_SESSION['customer']){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p></form></div></body></html>';

        session_destroy();
    }else{

$customer="'".$_SESSION['customer']."'";

$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);

$res1 = mysql_query("SELECT * FROM orderinfo WHERE username=$customer");
$res2 = mysql_query("SELECT * FROM customer WHERE username=$customer");
$row2= mysql_fetch_assoc($res2);

require "Cart.html";
echo '<div class="adduser-card">';
echo '<table>
<tr>
<th>OrderID</th>
<th>Order date</th>
<th>Total price</th>
<th>Total quantity</th>
<th>View order detail</th>
</tr>';
while($row1 = mysql_fetch_assoc($res1)){
    echo '<form action="orderdetail.php" method="post">';
    echo '<tr>';
    echo "<td>" .$row1['orderID']. "</td>";
    echo "<td>" .$row1['orderdate']. "</td>";
    echo "<td>" .$row1['totalprice']. "</td>";
    echo "<td>" .$row1['totalqty']. "</td>";
    echo '<td><input type="submit"  class="add add-submit" name="vieworderdetail" value="View order detail"></td>';

    echo '</tr>';
    echo '<input type="hidden"  name="orderID" value="'.$row1['orderID'].'">';
    echo '</form>';
}
echo '</table></div></body></html>';

mysql_close($con);

    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p></form></div></body></html>';
}?>