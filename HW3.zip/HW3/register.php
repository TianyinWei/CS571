<?php

session_start();
$t = time();


    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p></form></div></body></html>';

        session_destroy();
    }else{

        $username = "'".$_POST['username']."'";
        $password = "'".$_POST['pw']."'";
        $firstname = "'".$_POST['fname']."'";
        $lastname = "'".$_POST['lname']."'";
        $addr = "'".$_POST['addr']."'";
        $zipcode = "'".$_POST['zipcode']."'";
        $card = "'".$_POST['card']."'";
        $expdate = $_POST['expdate'];
        $security = $_POST['security'];

        $userindex = "";

        $con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
        if (!$con) {
            die("connection fail");	}
        mysql_select_db('mydatabase',$con);

//print_r($age);
        $sql2 = "SELECT * FROM customer WHERE username=$username";
        $res2 = mysql_query($sql2);
        $row2 = mysql_fetch_assoc($res2);
//require "test.html";
//print_r($username);

        if(!isset($row2['username'])){
            $sql1 = "INSERT INTO customer(username,password,firstname,lastname,address,zipcode,cardnumber,expdate,securitycode)VALUES
($username,
$password,$firstname,$lastname,$addr,$zipcode,$card,$expdate,$security)";
            $res1 = mysql_query($sql1);
            if($res1){
                require 'postregister.html';
              //  echo '<input type="submit" name="Adminhome" class="add add-submit" value="Back to home page">';
                echo '<p>New user created successfully!</p>';
                echo '<b><a href="mylogin.php">Please login again</a></b>';
                echo '</form></div></body></html>';
            }
            else{
                require 'postregister.html';
            //    echo '<input type="submit" name="Adminhome" class="add add-submit" value="Back to home page">';
                echo '<p>Error in creating the user.</p>';
                echo '<b><a href="register.html">Please register again</a></b>';
                echo '</form></div></body></html>';
            }
        }
        else{
            require "register.html";
            echo '<p style="color:red">Username already exists!</p></form></div></body></html>';

        }
        mysql_close($con);
/*   }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p>';
    require "postlogin.html";
}*/
}



?>