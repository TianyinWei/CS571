<?php

session_start();
$t = time();
if ($_SESSION['customer']){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p></form></div></body></html>';

        session_destroy();
    }else{


$pw = "'".$_POST['pw']."'";
$fname = "'".$_POST['fname']."'";
$lname = "'".$_POST['lname']."'";
$addr = "'".$_POST['addr']."'";
$zipcode =  "'".$_POST['zipcode']."'";
$card = "'".$_POST['card']."'";
$expdate = "'".$_POST['expdate']."'";
$security = $_POST['security'];

$customerID = "'".$_POST['customerID']."'";

$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);

$res = mysql_query("UPDATE customer SET password=$pw, firstname=$fname, lastname=$lname, address=$addr,zipcode=$zipcode,
cardnumber=$card, expdate=$expdate,securitycode=$security WHERE customerID=$customerID");

if($res){
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Now you have edited your personal profile. Please log in !</p>';
    echo '</div></body></html>';}

mysql_close($con);
    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p></form></div></body></html>';
}
?>