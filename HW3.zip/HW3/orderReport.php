<?php
session_start();
$startdate = $_POST['startdate'];
$enddate = $_POST['enddate'];
$checkitem = $_POST['checkitem'];
$sortby = $_POST['sortby'];
$totalsales = "'".$_POST['totalsales']."'";
$sortorder = $_POST['sortorder'];

/*printf($sortorder);
printf($sortby);
printf($checkitem);
printf($startdate);
printf($enddate);*/


$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);

require "orderReport.html";
echo '<div class="orderdetail">';

if((!$startdate)&&(!$enddate)){
    if($checkitem=='product') {
        if ($sortby == 'quantity') {
            $res = mysql_query("SELECT SUM(oi.quantity) as sumqty,p.productID,p.prodname,oi.price,p.prodimg,oi.quantity,pc.prodcategoryname,o.orderdate
FROM
orderinfo as o,
orderitem as oi,Product as p,ProdCategory as pc WHERE o.orderID=oi.orderID and p.productID=oi.productID and p
.prodcategoryID=pc.prodcategoryID
 GROUP BY p.productID  ORDER
 BY sumqty " . $sortorder);
            echo '<table>';
            echo '<tr>';
            echo '<th>Product view</th>';
            echo '<th>Product ID</th>';
            echo '<th>Product name</th>';
            echo '<th>Quantity sold</th>';
            echo '<th>Price</th>';
            echo '<th>Order date</th>';
            echo '<th>Total quantity sold</th>';
            echo '</tr>';
            while($row = mysql_fetch_assoc($res)){
                $subtotal = round($row['price'],2);
                echo '<tr>';
                echo '<td><img src="' . $row['prodimg'] . '" alt="' . $row['prodimg'] . '" height="150" width="200"></td>';
                echo "<td>".$row['productID']."</td>";
                echo "<td>".$row['prodname']."</td>";
                echo "<td>".$row['quantity']."</td>";
                echo "<td>$".$subtotal."</td>";
                echo "<td>".$row['orderdate']."</td>";
                echo "<td>".$row['sumqty']."</td>";
                echo '</tr>';
            }
            echo '</table>';}
        if ($sortby == 'price') {
            $res = mysql_query("SELECT SUM(oi.quantity*oi.price) as sumprice,p.productID,p.prodname,p.prodimg,oi.price,oi.quantity,pc.prodcategoryname,o
.orderdate FROM
orderinfo as o,orderitem as oi, Product as p,ProdCategory as pc WHERE o.orderID=oi.orderID and p.productID=oi
.productID and p.prodcategoryID=pc.prodcategoryID   GROUP
BY p.productID ORDER BY sumprice " . $sortorder);

            echo '<table>';
            echo '<tr>';
            echo '<th>Product view</th>';
            echo '<th>Product ID</th>';
            echo '<th>Product name</th>';
            echo '<th>Quantity sold</th>';
            echo '<th>Price</th>';
            echo '<th>Order date</th>';
            echo '<th>Total sales sold</th>';
            echo '</tr>';
            while ($row = mysql_fetch_assoc($res)) {
                $subtotal1 = round($row['price'],2);
                $subtotal2 = round($row['sumprice'],2);

                echo '<tr>';
                echo '<td><img src="' . $row['prodimg'] . '" alt="' . $row['prodimg'] . '" height="150" width="200"></td>';
                echo "<td>" . $row['productID'] . "</td>";
                echo "<td>" . $row['prodname'] . "</td>";
                echo "<td>" . $row['quantity'] . "</td>";
                echo "<td>$" . $subtotal1. "</td>";
                echo "<td>" . $row['orderdate'] . "</td>";
                echo "<td>$" . $subtotal2. "</td>";
                echo '</tr>';
            }
            echo '</table>';
        }
    }

    if($checkitem=='category') {
        if ($sortby == 'quantity') {
            $res = mysql_query("SELECT SUM(oi.quantity) as sumqty,p.productID,p.prodname,oi.price,oi.quantity,pc.prodcategoryname,pc.prodcategoryID,o
.orderdate FROM
orderinfo as o,
orderitem as oi,Product as p,ProdCategory as pc WHERE o.orderID=oi.orderID and p.productID=oi.productID and p
.prodcategoryID=pc.prodcategoryID
 GROUP BY pc.prodcategoryID  ORDER
 BY sumqty " . $sortorder);
            echo '<form action="reportcat.php" method="post">';
            while($row = mysql_fetch_assoc($res)){
                echo '<input type="radio" name="category" value="'.$row['prodcategoryID'].'">Category name:'
                    .$row['prodcategoryname'].'with total quantity of '.$row['sumqty'].'<br>';
            }
            echo '<input type="submit" class="add add-submit" name="submit" value="View details of selected category">';

            echo '</form>';

        }
        if ($sortby == 'price') {
            $res = mysql_query("SELECT SUM(oi.quantity*oi.price) as sumprice,p.productID,p.prodname,oi.price,oi.quantity,pc.prodcategoryname,pc
.prodcategoryID,o
.orderdate FROM
orderinfo as o,orderitem as oi, Product as p,ProdCategory as pc WHERE o.orderID=oi.orderID and p.productID=oi
.productID and p.prodcategoryID=pc.prodcategoryID
GROUP BY pc.prodcategoryID ORDER BY sumprice " . $sortorder);
            echo '<form action="reportcat.php" method="post">';
            while($row = mysql_fetch_assoc($res)){
                $subtotal = round($row['price'],2);

                echo '<input type="radio" name="category" value="'.$row['prodcategoryID'].'">Category name:'
                    .$row['prodcategoryname'].'with total sales of $'.$subtotal.'<br>';
            }
            echo '<input type="submit" class="add add-submit" name="submit" value="View details of selected category">';

            echo '</form>';
        }

    }

    if($checkitem=='specialsales'){

                if ($sortby == 'quantity') {
                    $res = mysql_query("SELECT SUM(oi.quantity) as sumqty,p.productID,p.prodname,p.prodimg,oi.price,oi.quantity,o.orderdate,s.startdate, s
.enddate FROM
orderinfo as o,orderitem as oi,Product as p,SpecialSales as s WHERE( o.orderID=oi.orderID and p.productID=oi
.productID and p.productID=s.productID and o.orderdate>=s.startdate and o.orderdate<=s.enddate)
 GROUP BY s.productID  ORDER
 BY sumqty " . $sortorder);
                    echo '<table>';
                    echo '<tr>';
                    echo '<th>Product view</th>';
                    echo '<th>Product ID</th>';
                    echo '<th>Product name</th>';
                    echo '<th>Quantity sold</th>';
                    echo '<th>Price</th>';
                    echo '<th>Order date</th>';
                    echo '<th>Total quantity sold</th>';
                    echo '</tr>';
                    while($row = mysql_fetch_assoc($res)){
                        $subtotal = round($row['price'],2);

                        echo '<tr>';
                        echo '<td><img src="' . $row['prodimg'] . '" alt="' . $row['prodimg'] . '" height="150" width="200"></td>';
                        echo "<td>".$row['productID']."</td>";
                        echo "<td>".$row['prodname']."</td>";
                        echo "<td>".$row['quantity']."</td>";
                        echo "<td>$".$subtotal."</td>";
                        echo "<td>".$row['orderdate']."</td>";
                        echo "<td>".$row['sumqty']."</td>";
                        echo '</tr>';
                    }
                }
                if ($sortby == 'price') {
                    $res = mysql_query("SELECT SUM(oi.quantity*oi.price) as sumprice,p.productID,p.prodname,p.prodimg,oi.price,oi.quantity,o.orderdate,s
.startdate, s
.enddate FROM orderinfo as o,orderitem as oi,Product as p,SpecialSales as s WHERE( o.orderID=oi.orderID and p
.productID=oi
.productID and p
.productID=s.productID and o.orderdate>=s.startdate and o.orderdate<=s.enddate)
 GROUP BY s.productID  ORDER
 BY sumprice " . $sortorder);
                    echo '<table>';
                    echo '<tr>';
                    echo '<th>Product view</th>';
                    echo '<th>Product ID</th>';
                    echo '<th>Product name</th>';
                    echo '<th>Quantity sold</th>';
                    echo '<th>Price</th>';
                    echo '<th>Order date</th>';
                    echo '<th>Total sales sold</th>';
                    echo '</tr>';
                    while ($row = mysql_fetch_assoc($res)) {
                        $subtotal1 = round($row['price'],2);
                        $subtotal2 = round($row['sumprice'],2);
                        echo '<tr>';
                        echo '<td><img src="' . $row['prodimg'] . '" alt="' . $row['prodimg'] . '" height="150" width="200"></td>';
                        echo "<td>" . $row['productID'] . "</td>";
                        echo "<td>" . $row['prodname'] . "</td>";
                        echo "<td>" . $row['quantity'] . "</td>";
                        echo "<td>$" .$subtotal1."</td>";
                        echo "<td>" . $row['orderdate'] . "</td>";
                        echo "<td>$" . $subtotal2 . "</td>";
                        echo '</tr>';
                    }
                    echo '</table>';
                }
            }
    if($checkitem=='totalsales') {
        $res = mysql_query("SELECT SUM(totalprice) as totalsales FROM orderinfo");
        $row=mysql_fetch_assoc($res);
        $subtotal1 = round($row['totalsales'],2);
        echo '<p style="font-size:1.5em;color:red">Total sales:$'.$subtotal1.'</p>';
    }
        }

else if($enddate>=$startdate){
    if ($checkitem == 'product') {
        if ($sortby == 'quantity') {
            $res = mysql_query("SELECT SUM(oi.quantity) as sumqty,p.productID,p.prodname,p.prodimg,oi.price,oi.quantity,pc.prodcategoryname,o.orderdate
FROM
orderinfo as o,
orderitem as oi,Product as p,ProdCategory as pc WHERE o.orderID=oi.orderID and p.productID=oi.productID and p
.prodcategoryID=pc.prodcategoryID and o.orderdate>='".$startdate."' and o.orderdate<='".$enddate."'
 GROUP BY p.productID  ORDER
 BY sumqty " . $sortorder);
            echo '<table>';
            echo '<tr>';
            echo '<th>Product view</th>';
            echo '<th>Product ID</th>';
            echo '<th>Product name</th>';
            echo '<th>Quantity sold</th>';
            echo '<th>Price</th>';
            echo '<th>Order date</th>';
            echo '<th>Total quantity sold</th>';
            echo '</tr>';
            while($row = mysql_fetch_assoc($res)){
                $subtotal = round($row['price'],2);

                echo '<tr>';
                echo '<td><img src="' . $row['prodimg'] . '" alt="' . $row['prodimg'] . '" height="150" width="200"></td>';
                echo "<td>".$row['productID']."</td>";
                echo "<td>".$row['prodname']."</td>";
                echo "<td>".$row['quantity']."</td>";
                echo "<td>$".$subtotal."</td>";
                echo "<td>".$row['orderdate']."</td>";
                echo "<td>".$row['sumqty']."</td>";
                echo '</tr>';
            }
            echo '</table>';
        }
        if ($sortby == 'price') {
            $res = mysql_query("SELECT SUM(oi.quantity*oi.price) as sumprice,p.productID,p.prodname,p.prodimg,oi.price,oi.quantity,pc
.prodcategoryname,o
.orderdate FROM
orderinfo as o,orderitem as oi, Product as p,ProdCategory as pc WHERE o.orderID=oi.orderID and p.productID=oi
.productID and p.prodcategoryID=pc.prodcategoryID and o.orderdate>='".$startdate."' and o.orderdate<='".$enddate."'  GROUP
BY p.productID ORDER BY sumprice " . $sortorder);
            echo '<table>';
            echo '<tr>';
            echo '<th>Product view</th>';
            echo '<th>Product ID</th>';
            echo '<th>Product name</th>';
            echo '<th>Quantity sold</th>';
            echo '<th>Price</th>';
            echo '<th>Order date</th>';
            echo '<th>Total sales sold</th>';
            echo '</tr>';
            while ($row = mysql_fetch_assoc($res)) {
                $subtotal1 = round($row['price'],2);
                $subtotal2 = round($row['sumprice'],2);

                echo '<tr>';
                echo '<td><img src="' . $row['prodimg'] . '" alt="' . $row['prodimg'] . '" height="150" width="200"></td>';
                echo "<td>" . $row['productID'] . "</td>";
                echo "<td>" . $row['prodname'] . "</td>";
                echo "<td>" . $row['quantity'] . "</td>";
                echo "<td>$" . $subtotal1 . "</td>";
                echo "<td>" . $row['orderdate'] . "</td>";
                echo "<td>$" . $subtotal2. "</td>";
                echo '</tr>';
            }
            echo '</table>';
        }
    }

    if ($checkitem == 'category') {
        if ($sortby == 'quantity') {
            $res = mysql_query("SELECT SUM(oi.quantity) as sumqty,p.productID,p.prodname,oi.price,oi.quantity,pc.prodcategoryname,pc.prodcategoryID,o
.orderdate FROM
orderinfo as o,
orderitem as oi,Product as p,ProdCategory as pc WHERE o.orderID=oi.orderID and p.productID=oi.productID and p
.prodcategoryID=pc.prodcategoryID and o.orderdate>='".$startdate."' and o.orderdate<='".$enddate."'
 GROUP BY pc.prodcategoryID  ORDER
 BY sumqty " . $sortorder);
            echo '<form action="reportcat.php" method="post">';
            while($row = mysql_fetch_assoc($res)){
                echo '<input type="radio" name="category" value="'.$row['prodcategoryID'].'">Category name:'
                    .$row['prodcategoryname'].'with total quantity of '.$row['sumqty'].'<br>';
            }
            echo '<input type="submit" class="add add-submit" name="submit" value="View details of selected category">';

            echo '</form>';

        }
        if ($sortby == 'price') {
            $res = mysql_query("SELECT SUM(oi.quantity*oi.price) as sumprice,p.productID,p.prodname,oi.price,oi.quantity,pc.prodcategoryname,pc
.prodcategoryID,o
.orderdate FROM
orderinfo as o,orderitem as oi, Product as p,ProdCategory as pc WHERE o.orderID=oi.orderID and p.productID=oi
.productID and p.prodcategoryID=pc.prodcategoryID and o.orderdate>='".$startdate."' and o.orderdate<='".$enddate."'  GROUP
BY pc.prodcategoryID ORDER BY sumprice " . $sortorder);
            echo '<form action="reportcat.php" method="post">';
            while($row = mysql_fetch_assoc($res)){
                $subtotal = round($row['sumprice'],2);

                echo '<input type="radio" name="category" value="'.$row['prodcategoryID'].'">Category name:'
                    .$row['prodcategoryname'].'with total sales of $'.$subtotal.'<br>';
            }
            echo '<input type="submit" class="add add-submit" name="submit" value="View details of selected category">';

            echo '</form>';
        }
    }

    if ($checkitem == 'specialsales') {

        if ($sortby == 'quantity') {
            $res = mysql_query("SELECT SUM(oi.quantity) as sumqty,p.productID,p.prodname,p.prodimg,oi.price,oi.quantity,o.orderdate,s.startdate, s
.enddate FROM
orderinfo as o,orderitem as oi,Product as p,SpecialSales as s WHERE o.orderID=oi.orderID and p.productID=oi
.productID and p
.productID=s.productID and o.orderdate>='" . $startdate . "' and o.orderdate<='" . $enddate . "'and o.orderdate>=s.startdate and o.orderdate<=s.enddate
 GROUP BY s.productID  ORDER
 BY sumqty " . $sortorder);
            echo '<table>';
            echo '<tr>';
            echo '<th>Product view</th>';
            echo '<th>Product ID</th>';
            echo '<th>Product name</th>';
            echo '<th>Quantity sold</th>';
            echo '<th>Price</th>';
            echo '<th>Order date</th>';
            echo '<th>Total quantity sold</th>';
            echo '</tr>';
            while ($row = mysql_fetch_assoc($res)) {
                $subtotal1 = round($row['price'], 2);

                echo '<tr>';
                echo '<td><img src="' . $row['prodimg'] . '" alt="' . $row['prodimg'] . '" height="150" width="200"></td>';
                echo "<td>" . $row['productID'] . "</td>";
                echo "<td>" . $row['prodname'] . "</td>";
                echo "<td>" . $row['quantity'] . "</td>";
                echo "<td>$" . $subtotal1 . "</td>";
                echo "<td>" . $row['orderdate'] . "</td>";
                echo "<td>" . $row['sumqty'] . "</td>";
                echo '</tr>';
            }
        }
        if ($sortby == 'price') {
            $res = mysql_query("SELECT SUM(oi.quantity*oi.price) as sumprice,p.productID,p.prodname,p.prodimg,oi.price,oi.quantity,o.orderdate,s
.startdate,s
.enddate FROM
orderinfo as o,orderitem as oi,Product as p,SpecialSales as s WHERE o.orderID=oi.orderID and p.productID=oi
.productID and p
.productID=s.productID and o.orderdate>='" . $startdate . "' and o.orderdate<='" . $enddate . "' and o.orderdate>=s.startdate and o.orderdate<=s.enddate
 GROUP BY s.productID  ORDER
 BY sumprice " . $sortorder);
            echo '<table>';
            echo '<tr>';
            echo '<th>Product view</th>';
            echo '<th>Product ID</th>';
            echo '<th>Product name</th>';
            echo '<th>Quantity sold</th>';
            echo '<th>Price</th>';
            echo '<th>Order date</th>';
            echo '<th>Total sales sold</th>';
            echo '</tr>';
            while ($row = mysql_fetch_assoc($res)) {
                $subtotal2 = round($row['sumprice'], 2);
                $subtotal1 = round($row['price'], 2);
                echo '<tr>';
                echo '<td><img src="' . $row['prodimg'] . '" alt="' . $row['prodimg'] . '" height="150" width="200"></td>';
                echo "<td>" . $row['productID'] . "</td>";
                echo "<td>" . $row['prodname'] . "</td>";
                echo "<td>" . $row['quantity'] . "</td>";
                echo "<td>$" . $subtotal1 . "</td>";
                echo "<td>" . $row['orderdate'] . "</td>";
                echo "<td>$" . $subtotal2 . "</td>";
                echo '</tr>';
            }
            echo '</table>';
        }
    }
        if($checkitem=='totalsales'){
            $res = mysql_query("SELECT SUM(totalprice) as totalsales FROM orderinfo WHERE orderdate>='" . $startdate . "' and orderdate<='" . $enddate . "'");
            $row=mysql_fetch_assoc($res);
            $subtotal1 = round($row['totalsales'],2);
            echo '<p style="font-size:1.5em;color:red">Total sales in the selected date range is:$'.$subtotal1.'</p>';
        }


}
else{
    echo '<p style="font-size:1.5em;color:red">Please specify a valid date range.</p>';
}


echo '</body></html>';

mysql_close($con);
?>

