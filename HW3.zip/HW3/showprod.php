<?php
session_start();
$t = time();
if ($_SESSION['customer']) {

    if (($_SESSION['timeout'] + 180) < $t) {
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p></form></div></body></html>';

        session_destroy();
    } else {

        $customer = "'" . $_SESSION['customer'] . "'";
        $catname = "'".$_POST['choosecat']."'";

        $con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
        if (!$con) {
            die("connection fail");
        }
        mysql_select_db('mydatabase', $con);

        date_default_timezone_set('America/Los_Angeles');
        $today = date("Y-m-d"); // ("Y-m-d H:i:s") - DateTime

        require "prodpage.html";

echo '<p style="position:relative;top:-2.4in;color:darkviolet;text-align:right;font-size:1.2em">Welcome!
    '.$_SESSION['customer'].'~</p>';
//  echo '<a style="position:relative;top:-2.6in;color:darkviolet;text-align:right" href="logout.php">Logout</a>';

        $res4 = mysql_query("SELECT * FROM ProdCategory");
        echo '<form method="post" action="showprod.php">';

        while ($row4 = mysql_fetch_assoc($res4)) {
            echo '<input type="submit" class="add add-submit" style="position:relative;left:1.5in" name="choosecat" value="'
                . $row4['prodcategoryname'] . '"><span style="position:relative;left:1.5in">';
        }
        echo '</span></span></span</span></span></span></form>';

        $res1 = mysql_query("SELECT * FROM ProdCategory WHERE prodcategoryname=$catname");
        $row1 = mysql_fetch_assoc($res1);
        $catID = $row1['prodcategoryID'];

        $res2 = mysql_query("SELECT * FROM Product WHERE prodcategoryID='" . $row1['prodcategoryID'] . "'");

    echo '<table>';
    while ($row2 = mysql_fetch_assoc($res2)){
    $res3 = mysql_query("SELECT * FROM SpecialSales WHERE productID='" . $row2['productID'] . "'");
    $row3 = mysql_fetch_assoc($res3);
    $enddate = $row3['enddate'];
    echo '<form style="text-align: center" action="viewdetail.php" method="POST">';
        echo '<tr>';
            echo '<td><img src="' . $row2['prodimg'] . '" alt="' . $row2['prodimg'] . '" height="200" width="250"></td>';
            echo '<td><p style="font-size: 1.3em">' . $row2['prodname'] . '</p></td>';
            if($enddate>=$today){
            echo '<td><p style="text-decoration: line-through">Original Price:$' . $row2['prodprice'] . '</p>';
                echo '<p style="color:blueviolet;font-size: 1.5em">Now:$' . $row3['price'] . '</p></td>';
            echo '<td><p style="color:blueviolet;font-size:2em">ON SALE!!</p></td>';

            }else{
            echo '<td><p style="font-size: 1.3em">Price:$' . $row2['prodprice'] . '</p></td>';
            echo '<td></td>';
            }
            echo '<td><input type="submit"  class="add add-submit" name="viewdetail" value="View product detail"></td>';

            // echo '<input type="submit" name="viewdetail" value="View product details"></div>';
            echo '</tr>';
        echo '<input type="hidden" name="productID" value="' . $row2['productID'] . '" >';
        echo '</form>';

    }
    echo '</table></body></html>';

mysql_close($con);
}
}
else{
require "prelogin.html";
echo '<p style="font-size:25px;color:red">Please log in first!</p></form></div></body></html>';
}
?>

