<?php

session_start();
$t = time();
if ($_SESSION['customer']){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p></form></div></body></html>';

        session_destroy();
    }else{

$customer="'".$_SESSION['customer']."'";

$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);

$orderid = $_POST['orderID'];
$res2 = mysql_query("SELECT * FROM orderitem WHERE orderID=$orderid");

require "Cart.html";
echo '<div class="orderdetail">';

echo '<table>
<tr>
<th>OrderID</th>
<th>Name</th>
<th>Shipped to</th>
<th>Product name</th>
<th>Price</th>
<th>Quantity</th>
<th>Product view</th>
</tr>';
while($row2 = mysql_fetch_assoc($res2)){
    $res1 = mysql_query("SELECT * FROM orderinfo WHERE orderID=$orderid");
    $row1 = mysql_fetch_assoc($res1);
    $prodID = "'".$row2['productID']."'";
    $res3 = mysql_query("SELECT * FROM Product WHERE productID=$prodID");
    $row3 = mysql_fetch_assoc($res3);
    echo '<form action="orderdetail.php" metho="post">';
    echo '<tr>';
    echo "<td>$orderid</td>";
    echo "<td>" .$row1['firstname']. "".$row1['lastname']."</td>";
    echo "<td><p>" .$row1['address']. "</p><p>".$row1['zipcode']."</p></td>";
    echo "<td>" .$row2['prodname']."</td>";
    echo "<td>$" .$row2['price']."</td>";
    echo "<td>" .$row2['quantity']."</td>";
    echo '<td><img src="' . $row3['prodimg'] . '" alt="' . $row2['prodimg'] . '" height="150" width="200"></td>';
    echo '<tr>';

}
echo '</table></div></body></html>';
mysql_close($con);
}
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p></form></div></body></html>';
}
?>