<?php
session_start();
$t = time();
if ($_SESSION['customer']){

if (($_SESSION['timeout']+180)<$t){
    //header("location:mylogin.php");
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p></form></div></body></html>';

    session_destroy();
}else{

$prodID = $_POST['productID'];


$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);

date_default_timezone_set('America/Los_Angeles');
$today = date("Y-m-d"); // ("Y-m-d H:i:s") - DateTime

$sql1 = "SELECT * FROM SpecialSales WHERE productID=$prodID";
$res1 = mysql_query($sql1);
$row1 = mysql_fetch_assoc($res1);
$enddate=$row1['enddate'];

$sql2 = "SELECT * FROM Product WHERE productID=$prodID";
$res2 = mysql_query($sql2);
$row2 = mysql_fetch_assoc($res2);


require 'Cart.html';
echo '<h1>View Product</h1>';

if($enddate>=$today){
    echo '<form action="Cart.php" method="POST">';
    echo '<div class="adduser-card">';
    echo '<img src="' . $row2['prodimg'] . '" alt="' . $row2['prodimg'] . '" height="200" width="250"><br>';
    echo '<p>' . $row2['prodname'] . '</p>';
    echo '<p>' . $row2['proddescription'] . '</p>';
    echo '<p style="text-decoration: line-through">Original Price:$' . $row2['prodprice'] . '</p>';
    echo '<p>Now:$' . $row1['price'] . '</p>';
    echo '<p>Sale date:'.$row1['startdate'].'~'.$row1['enddate'].'</p>';
    echo '<p>In stock:'.$row2['storage'].'</p>';
    echo 'Quantity you want:<input type="number" name="quantity" min="1" max="'.$row2['storage'].'" required/><br>';
    echo '<input type="hidden" name="productID" value="'.$row2['productID'].'">';
    echo '<input type="hidden" name="catID" value="'.$row2['prodcategoryID'].'">';

    echo '<input type="submit"  class="add add-submit" name="addtocart" value="Add to cart">';
    echo '</div></form></body></html>';

    $_SESSION['cartprodname'] ="'" . $row2['prodname'] ." '";
    $_SESSION['cartprodprice'] ="'" . $row1['price'] ." '";

}

else{
    echo '<form action="Cart.php" method="POST">';
    echo '<div class="adduser-card">';
    echo '<img src="' . $row2['prodimg'] . '" alt="' . $row2['prodimg'] . '" height="200" width="250"><br>';
    echo '<p>' . $row2['prodname'] . '</p>';
    echo '<p>' . $row2['proddescription'] . '</p>';
    echo '<p>Price:$' . $row2['prodprice'] . '</p>';
    echo '<p>In stock:'.$row2['storage'].'</p>';
    echo 'Quantity you want:<input type="number" name="quantity" max="'.$row2['storage'].'" required/><br>';
    echo '<input type="hidden" name="productID" value="'.$row2['productID'].'">';
    echo '<input type="hidden" name="catID" value="'.$row2['prodcategoryID'].'">';

    echo '<input type="submit"  class="add add-submit" name="addtocart" value="Add to cart">';
    echo '</div></form></body></html>';

    $_SESSION['cartprodname'] ="'" . $row2['prodname'] ." '";
    $_SESSION['cartprodprice'] ="'" . $row2['prodprice'] ." '";

}




mysql_close($con);
}
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p></form></div></body></html>';
}
?>
