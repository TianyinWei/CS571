<?php
session_start();
$t = time();
if ($_SESSION['customer']){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p></form></div></body></html>';

        session_destroy();
    }else{

$customer="'".$_SESSION['customer']."'";

$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);

$res = mysql_query("SELECT * FROM cart WHERE username=$customer");
$resbug = mysql_query("SELECT * FROM cart WHERE username=$customer");

$res4 = mysql_query("SELECT SUM(price*quantity) FROM cart WHERE username=$customer");
$row4 = mysql_fetch_assoc($res4);
$totalprice =$row4['SUM(price*quantity)'];
//printf($totalprice);
$res44 = mysql_query("SELECT SUM(quantity) FROM cart WHERE username=$customer");
$row44 = mysql_fetch_assoc($res44);
$totalqty =$row44['SUM(quantity)'];

require "Cart.html";
echo "<h1>My cart</h1>";

if(!($row6 = mysql_fetch_assoc($res))){
        echo '<div class="adduser-card">';
        echo '<p>Your cart is empty</p>';
        echo '</div></body></html>';


}else {
    while ($row = mysql_fetch_assoc($resbug)) {
        $res2 = mysql_query("SELECT * FROM Product WHERE productID='" . $row['productID'] . "'");
        $row2 = mysql_fetch_assoc($res2);
        echo '<div class="adduser-card">';
        echo '<form action="editCart.php" method="POST">';
        echo '<img src="' . $row2['prodimg'] . '" alt="' . $row2['prodimg'] . '" height="120" width="120"><br>';
        echo '<p>' . $row['prodname'] . '</p>';
        echo '<p>Price:$' . $row['price'] . '</p>';
        echo '<input type="hidden" name="productID" value="' . $row['productID'] . '">';
        echo '<input type="hidden" name="catID" value="' . $row['catID'] . '">';
        echo '<input type="number" name="quantity" value="' . $row['quantity'] . '" min="1" max="'.$row2['storage']
            .'" >';
        echo '<input type="hidden" name="cartindex" value="' . $row['cartindex'] . '">';
        // print_r($row['cartindex']);
        echo '<span style="position:relative;left:.5in"><input type="submit"  class="add add-submit" name="editcart"
value="Confirm Change">';
        echo '<span style="position:relative;left:.5in"><input type="submit"  class="add add-submit" name="editcart"
value="Delete this item"></span></span></form></div>';
    }
    echo '<div class="adduser-card">';
    $subtotal = round($row4["SUM(price*quantity)"],2);
    //echo '<p>Subtotal:$round($row4["SUM(price*quantity)"],2)</p>';
    print_r("Subtotal:$");
    print_r($subtotal);
    echo '<p>Total quantity:'.$row44['SUM(quantity)'].'</p>';
    echo '<form action="editCart.php" method="POST">';
    echo '<input type="submit" class="add add-submit" name="editcart" value="Clear shopping cart"></form>';
    echo '<br>';
    echo '<form action="preCheckout.php" method="POST">';
    echo '<input type="submit" class="add add-submit" name="editcart"
value="Proceed to Checkout"></form>';
    echo '</div></body></html>';

}

mysql_close($con);
    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p></form></div></body></html>';
}
?>