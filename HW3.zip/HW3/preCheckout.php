<?php

session_start();
$t = time();
if ($_SESSION['customer']){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p></form></div></body></html>';

        session_destroy();
    }else {
        $customer = "'" . $_SESSION['customer'] . "'";

        $con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
        if (!$con) {
            die("connection fail");
        }
        mysql_select_db('mydatabase', $con);

        $sql1 = "SELECT * FROM cart WHERE username=$customer";
        $res1 = mysql_query($sql1);

        $sql2 = "SELECT * FROM customer WHERE username=$customer";
        $res2 = mysql_query($sql2);
        $row2 = mysql_fetch_assoc($res2);

        require "Cart.html";
        echo '<b class="logout"><a href="viewCart.php">View my cart</a></b>';

        echo '<h1>Order list</h1>';
        echo '<form action="placeOrder.php" method="POST">';

        while ($row1 = mysql_fetch_assoc($res1)) {
            $prodID = $row1['productID'];
            $res3 = mysql_query("SELECT * FROM Product WHERE productID=$prodID");
            $row3 = mysql_fetch_assoc($res3);
            echo '<div class="adduser-card">';
            echo '<img src="' . $row3['prodimg'] . '" alt="' . $row3['prodimg'] . '" height="200" width="250">';

            echo '<p>' . $row1['prodname'] . '</p>';
            echo '<p>Price:$' . $row1['price'] . '</p>';
            echo '<p>Quantity:' . $row1['quantity'] . '</p>';
            echo '<input type="hidden" name="cartindex" value="' . $row1['cartindex'] . '"></div>';
        }
        echo '<div class="adduser-card">';
        echo '<p style="font-size:1.5em">Ship to:(you can edit shipping info below)</p>';
        echo 'Firstname:<input type="text" name="fname" value="' . $row2['firstname'] . '" /required><br><br>';
        echo 'Lastname:<input type="text" name="lname" value="' . $row2['lastname'] . '"/required><br><br>';
        echo 'Address:<input type="text" name="addr" value="' . $row2['address'] . '"/required><br><br>';
        echo 'Zipcode:<input type="text" name="zipcode" pattern="[0-9]{5}" title="5-digit zipcode" value="' . $row2['zipcode'] . '"
/required><br>';

        echo '<input type="submit" class="add add-submit" name="placeorder" value="Ship to this address">';
        echo '</div>';

        echo '</form></body></html>';

        mysql_close($con);

    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p></form></div></body></html>';
}
?>