<?php

session_start();
$row=0;

$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);


date_default_timezone_set('America/Los_Angeles');
$today = date("Y-m-d"); // ("Y-m-d H:i:s") - DateTime

$sql3 = "SELECT * FROM SpecialSales";
$res3 = mysql_query($sql3);

require 'Homepage.html';

echo '<table>';
//echo '<tr>';
while ($row3 = mysql_fetch_assoc($res3)) {
    if(($row % 2) ==0){
    echo '<tr>';}
        $enddate = $row3['enddate'];
        if ($enddate >= $today) {
            $sql2 = "SELECT * FROM Product WHERE productID='" . $row3['productID'] . "'";
            $res2 = mysql_query($sql2);
            $row2 = mysql_fetch_assoc($res2);
            echo '<td>';

            echo '<div class="adduser-card">';
            echo '<form action="viewdetail.php" method="POST">';
            echo '<img src="' . $row2['prodimg'] . '" alt="' . $row2['prodimg'] . '" height="200" width="230"><br>';
            echo '<p style="font-size: 1.3em">' . $row2['prodname'] . '</p>';
            echo '<p style="text-decoration: line-through">Original Price:$' . $row2['prodprice'] . '</p>';
            echo '<p style="font-size: 1.5em;color:blueviolet">Now:$' . $row3['price'] . '</p>';
            echo '<input type="hidden" name="productID" value="' . $row3['productID'] . '" >';
            //echo '<input type="submit"  class="add add-submit" name="viewdetail" value="View product detail">';
            echo '</form></div></td>';


            if (($row % 2) == 1) {
                echo '</tr>';
            }
            $row = $row + 1;
        }

}
    echo '</table></body></html>';

mysql_close($con);

?>

