<?php

session_start();
$t = time();
if ($_SESSION['customer']){

    if (($_SESSION['timeout']+180)<$t){
        //header("location:mylogin.php");
        require "prelogin.html";
        echo '<p style="font-size:25px;color:red">Log in time out Please log in again.</p></form></div></body></html>';

        session_destroy();
    }else{

$customer="'".$_SESSION['customer']."'";

$con = mysql_connect('cs-server.usc.edu:7816', 'root', '920328');
if (!$con) {
    die("connection fail");	}
mysql_select_db('mydatabase',$con);

$res = mysql_query("SELECT * FROM customer WHERE username=$customer");
$row = mysql_fetch_assoc($res);

require "Cart.html";

echo '<div class="adduser-card"><form method="post" action="SQLeditprof.php">';
echo '<h1>Please edit your information below </h1>';
echo  '<p style="color:red;text-align: center">You cannot change your username.Otherwise please register as a new user.</p>
<form action="register.php" method="post">
    Username:<input type="text" id="username" name="username" value="'.$row['username'].'" readonly/><br><br>
Password:<input type="text" id="pw" name="pw" value="'.$row['password'].'" required/><br><br>
Firstname:<input type="text" id="fname" name="fname" value="'.$row['firstname'].'" required/><br><br>
Lastname:<input type="text" id="lname" name="lname" value="'.$row['lastname'].'" required/><br><br>
Shipping address: <input type="text" id="addr" name="addr" value="'.$row['address'].'" required/><br><br>
    Zipcode:<input type="number" id="zipcode" name="zipcode" value="'.$row['zipcode'].'"
    pattern="[0-9]{5}" title=""5-digit zipcode" required/><br><br>
Card number:<input type="text" id="card" name="card" value="'.$row['cardnumber'].'" pattern="[0-9]{16}"
title="16-digit card number" required/><br><br>
Expiration date:<input type="month" id="exdate" name="expdate" value="'.$row['expdate'].'" min="2015-07"
required/><br><br>
    Security code:<input type="text" id="security" name="security" value="'.$row['securitycode'].'" pattern="[0-9]{3}"
    title="3-digit security code"  required/><br><br>

<input type="hidden" id="customerID" name="customerID" value="'.$row['customerID'].'">';


echo  '<input type="submit" id="register" name="submit" class="add add-submit" value="Confirm my info">';
echo '</form></div></body></html>';

mysql_close($con);
    }
}
else{
    require "prelogin.html";
    echo '<p style="font-size:25px;color:red">Please log in first!</p></form></div></body></html>';
}
?>